<aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white border-r border-gray-100 flex flex-col z-20 shadow-sm"
    style="width: 240px; transition: width 0.3s ease; overflow: hidden;">

    
    <div class="px-4 py-5 border-b border-gray-100 flex items-center gap-2.5" style="min-height: 64px;">
        <div class="w-8 h-8 rounded-lg bg-primary-500 flex items-center justify-center flex-shrink-0">
            <svg class="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                <path
                    d="M3.75 6A2.25 2.25 0 016 3.75h2.25A2.25 2.25 0 0110.5 6v2.25a2.25 2.25 0 01-2.25 2.25H6a2.25 2.25 0 01-2.25-2.25V6zM3.75 15.75A2.25 2.25 0 016 13.5h2.25a2.25 2.25 0 012.25 2.25V18a2.25 2.25 0 01-2.25 2.25H6A2.25 2.25 0 013.75 18v-2.25zM13.5 6a2.25 2.25 0 012.25-2.25H18A2.25 2.25 0 0120.25 6v2.25A2.25 2.25 0 0118 10.5h-2.25a2.25 2.25 0 01-2.25-2.25V6zM13.5 15.75a2.25 2.25 0 012.25-2.25H18a2.25 2.25 0 012.25 2.25V18A2.25 2.25 0 0118 20.25h-2.25A2.25 2.25 0 0113.5 18v-2.25z" />
            </svg>
        </div>
        <div id="sidebar-brand-text" class="overflow-hidden whitespace-nowrap">
            <p class="text-sm font-semibold text-gray-900 leading-tight">Admin Panel</p>
            <p class="text-[10px] text-gray-400 leading-tight">Sistem Pertandingan</p>
        </div>
    </div>

    <nav class="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">

        <?php if (isset($component)) { $__componentOriginal25b36b426f30fd196f9d947e60e48c56 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal25b36b426f30fd196f9d947e60e48c56 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-link','data' => ['href' => ''.e(route('admin.dashboard')).'','active' => request()->routeIs('admin.dashboard'),'icon' => 'dashboard']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.dashboard')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.dashboard')),'icon' => 'dashboard']); ?>
            Dashboard
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal25b36b426f30fd196f9d947e60e48c56)): ?>
<?php $attributes = $__attributesOriginal25b36b426f30fd196f9d947e60e48c56; ?>
<?php unset($__attributesOriginal25b36b426f30fd196f9d947e60e48c56); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal25b36b426f30fd196f9d947e60e48c56)): ?>
<?php $component = $__componentOriginal25b36b426f30fd196f9d947e60e48c56; ?>
<?php unset($__componentOriginal25b36b426f30fd196f9d947e60e48c56); ?>
<?php endif; ?>

        <div class="pt-3 pb-1 px-3 sidebar-section-label">
            <p class="text-[10px] font-semibold text-gray-400 uppercase tracking-widest whitespace-nowrap">Data Master
            </p>
        </div>
        <?php if (isset($component)) { $__componentOriginal19667d6231f8d2a7fc135a984252ca90 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19667d6231f8d2a7fc135a984252ca90 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-group','data' => ['title' => 'Peserta','id' => 'peserta','icon' => 'users','active' => request()->is('admin/peserta*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Peserta','id' => 'peserta','icon' => 'users','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->is('admin/peserta*'))]); ?>
            <?php if (isset($component)) { $__componentOriginalf2eb903004b40910827d3ecebcb63da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2eb903004b40910827d3ecebcb63da9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-sublink','data' => ['href' => ''.e(route('admin.peserta.solo.index')).'','active' => request()->routeIs('admin.peserta.solo.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.peserta.solo.index')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.peserta.solo.*'))]); ?>Solo <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $attributes = $__attributesOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $component = $__componentOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__componentOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalf2eb903004b40910827d3ecebcb63da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2eb903004b40910827d3ecebcb63da9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-sublink','data' => ['href' => ''.e(route('admin.peserta.ganda.index')).'','active' => request()->routeIs('admin.peserta.ganda.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.peserta.ganda.index')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.peserta.ganda.*'))]); ?>Ganda <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $attributes = $__attributesOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $component = $__componentOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__componentOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalf2eb903004b40910827d3ecebcb63da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2eb903004b40910827d3ecebcb63da9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-sublink','data' => ['href' => ''.e(route('admin.peserta.tunggal.index')).'','active' => request()->routeIs('admin.peserta.tunggal.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.peserta.tunggal.index')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.peserta.tunggal.*'))]); ?>Tunggal <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $attributes = $__attributesOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $component = $__componentOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__componentOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalf2eb903004b40910827d3ecebcb63da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2eb903004b40910827d3ecebcb63da9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-sublink','data' => ['href' => ''.e(route('admin.peserta.regu.index')).'','active' => request()->routeIs('admin.peserta.regu.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.peserta.regu.index')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.peserta.regu.*'))]); ?>Regu <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $attributes = $__attributesOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $component = $__componentOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__componentOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalf2eb903004b40910827d3ecebcb63da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2eb903004b40910827d3ecebcb63da9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-sublink','data' => ['href' => ''.e(route('admin.peserta.pool.index')).'','active' => request()->routeIs('admin.peserta.pool.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.peserta.pool.index')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.peserta.pool.*'))]); ?>Pool
                (Seni) <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $attributes = $__attributesOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $component = $__componentOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__componentOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19667d6231f8d2a7fc135a984252ca90)): ?>
<?php $attributes = $__attributesOriginal19667d6231f8d2a7fc135a984252ca90; ?>
<?php unset($__attributesOriginal19667d6231f8d2a7fc135a984252ca90); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19667d6231f8d2a7fc135a984252ca90)): ?>
<?php $component = $__componentOriginal19667d6231f8d2a7fc135a984252ca90; ?>
<?php unset($__componentOriginal19667d6231f8d2a7fc135a984252ca90); ?>
<?php endif; ?>

        <div class="pt-3 pb-1 px-3 sidebar-section-label">
            <p class="text-[10px] font-semibold text-gray-400 uppercase tracking-widest whitespace-nowrap">Operasional
            </p>
        </div>
        <?php if (isset($component)) { $__componentOriginal19667d6231f8d2a7fc135a984252ca90 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19667d6231f8d2a7fc135a984252ca90 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-group','data' => ['title' => 'Manajemen','id' => 'manajemen','icon' => 'management','active' => request()->is('admin/manajemen*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Manajemen','id' => 'manajemen','icon' => 'management','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->is('admin/manajemen*'))]); ?>
            <?php if (isset($component)) { $__componentOriginalf2eb903004b40910827d3ecebcb63da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2eb903004b40910827d3ecebcb63da9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-sublink','data' => ['href' => ''.e(route('admin.manajemen.solo.index')).'','active' => request()->routeIs('admin.manajemen.solo.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.manajemen.solo.index')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.manajemen.solo.*'))]); ?>Solo <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $attributes = $__attributesOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $component = $__componentOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__componentOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalf2eb903004b40910827d3ecebcb63da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2eb903004b40910827d3ecebcb63da9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-sublink','data' => ['href' => ''.e(route('admin.manajemen.ganda.index')).'','active' => request()->routeIs('admin.manajemen.ganda.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.manajemen.ganda.index')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.manajemen.ganda.*'))]); ?>Ganda <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $attributes = $__attributesOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $component = $__componentOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__componentOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalf2eb903004b40910827d3ecebcb63da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2eb903004b40910827d3ecebcb63da9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-sublink','data' => ['href' => ''.e(route('admin.manajemen.tunggal.index')).'','active' => request()->routeIs('admin.manajemen.tunggal.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.manajemen.tunggal.index')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.manajemen.tunggal.*'))]); ?>Tunggal <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $attributes = $__attributesOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $component = $__componentOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__componentOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalf2eb903004b40910827d3ecebcb63da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2eb903004b40910827d3ecebcb63da9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-sublink','data' => ['href' => ''.e(route('admin.manajemen.regu.index')).'','active' => request()->routeIs('admin.manajemen.regu.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.manajemen.regu.index')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.manajemen.regu.*'))]); ?>Regu <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $attributes = $__attributesOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $component = $__componentOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__componentOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalf2eb903004b40910827d3ecebcb63da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2eb903004b40910827d3ecebcb63da9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-sublink','data' => ['href' => ''.e(route('admin.manajemen.pool.index')).'','active' => request()->routeIs('admin.manajemen.pool.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.manajemen.pool.index')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.manajemen.pool.*'))]); ?>Pool
                (Seni) <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $attributes = $__attributesOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $component = $__componentOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__componentOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19667d6231f8d2a7fc135a984252ca90)): ?>
<?php $attributes = $__attributesOriginal19667d6231f8d2a7fc135a984252ca90; ?>
<?php unset($__attributesOriginal19667d6231f8d2a7fc135a984252ca90); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19667d6231f8d2a7fc135a984252ca90)): ?>
<?php $component = $__componentOriginal19667d6231f8d2a7fc135a984252ca90; ?>
<?php unset($__componentOriginal19667d6231f8d2a7fc135a984252ca90); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal25b36b426f30fd196f9d947e60e48c56 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal25b36b426f30fd196f9d947e60e48c56 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-link','data' => ['href' => ''.e(route('admin.manajemen.kelas.index')).'','active' => request()->routeIs('admin.manajemen.kelas.*'),'icon' => 'management']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.manajemen.kelas.index')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.manajemen.kelas.*')),'icon' => 'management']); ?>
            Data Kelas
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal25b36b426f30fd196f9d947e60e48c56)): ?>
<?php $attributes = $__attributesOriginal25b36b426f30fd196f9d947e60e48c56; ?>
<?php unset($__attributesOriginal25b36b426f30fd196f9d947e60e48c56); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal25b36b426f30fd196f9d947e60e48c56)): ?>
<?php $component = $__componentOriginal25b36b426f30fd196f9d947e60e48c56; ?>
<?php unset($__componentOriginal25b36b426f30fd196f9d947e60e48c56); ?>
<?php endif; ?>

        <div class="pt-3 pb-1 px-3 sidebar-section-label">
            <p class="text-[10px] font-semibold text-gray-400 uppercase tracking-widest whitespace-nowrap">Laporan</p>
        </div>
        <?php if (isset($component)) { $__componentOriginal19667d6231f8d2a7fc135a984252ca90 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19667d6231f8d2a7fc135a984252ca90 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-group','data' => ['title' => 'Hasil','id' => 'hasil','icon' => 'trophy','active' => request()->is('admin/hasil*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Hasil','id' => 'hasil','icon' => 'trophy','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->is('admin/hasil*'))]); ?>
            <?php if (isset($component)) { $__componentOriginalf2eb903004b40910827d3ecebcb63da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2eb903004b40910827d3ecebcb63da9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-sublink','data' => ['href' => ''.e(route('admin.hasil.solo.index')).'','active' => request()->routeIs('admin.hasil.solo.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.hasil.solo.index')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.hasil.solo.*'))]); ?>Solo <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $attributes = $__attributesOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $component = $__componentOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__componentOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalf2eb903004b40910827d3ecebcb63da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2eb903004b40910827d3ecebcb63da9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-sublink','data' => ['href' => ''.e(route('admin.hasil.ganda.index')).'','active' => request()->routeIs('admin.hasil.ganda.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.hasil.ganda.index')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.hasil.ganda.*'))]); ?>Ganda <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $attributes = $__attributesOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $component = $__componentOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__componentOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalf2eb903004b40910827d3ecebcb63da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2eb903004b40910827d3ecebcb63da9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-sublink','data' => ['href' => ''.e(route('admin.hasil.tunggal.index')).'','active' => request()->routeIs('admin.hasil.tunggal.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.hasil.tunggal.index')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.hasil.tunggal.*'))]); ?>Tunggal <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $attributes = $__attributesOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $component = $__componentOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__componentOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalf2eb903004b40910827d3ecebcb63da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2eb903004b40910827d3ecebcb63da9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-sublink','data' => ['href' => ''.e(route('admin.hasil.regu.index')).'','active' => request()->routeIs('admin.hasil.regu.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.hasil.regu.index')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.hasil.regu.*'))]); ?>Regu <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $attributes = $__attributesOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $component = $__componentOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__componentOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalf2eb903004b40910827d3ecebcb63da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2eb903004b40910827d3ecebcb63da9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-sublink','data' => ['href' => ''.e(route('admin.hasil.pool.index')).'','active' => request()->routeIs('admin.hasil.pool.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-sublink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.hasil.pool.index')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.hasil.pool.*'))]); ?>Pool <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $attributes = $__attributesOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__attributesOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2eb903004b40910827d3ecebcb63da9)): ?>
<?php $component = $__componentOriginalf2eb903004b40910827d3ecebcb63da9; ?>
<?php unset($__componentOriginalf2eb903004b40910827d3ecebcb63da9); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19667d6231f8d2a7fc135a984252ca90)): ?>
<?php $attributes = $__attributesOriginal19667d6231f8d2a7fc135a984252ca90; ?>
<?php unset($__attributesOriginal19667d6231f8d2a7fc135a984252ca90); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19667d6231f8d2a7fc135a984252ca90)): ?>
<?php $component = $__componentOriginal19667d6231f8d2a7fc135a984252ca90; ?>
<?php unset($__componentOriginal19667d6231f8d2a7fc135a984252ca90); ?>
<?php endif; ?>


    </nav>

    <div class="border-t border-gray-100 px-2 py-3">
        <?php if (isset($component)) { $__componentOriginal25b36b426f30fd196f9d947e60e48c56 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal25b36b426f30fd196f9d947e60e48c56 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-link','data' => ['href' => ''.e(route('admin.profile')).'','active' => request()->routeIs('admin.profile'),'icon' => 'user']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.profile')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.profile')),'icon' => 'user']); ?>
            Admin Profile
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal25b36b426f30fd196f9d947e60e48c56)): ?>
<?php $attributes = $__attributesOriginal25b36b426f30fd196f9d947e60e48c56; ?>
<?php unset($__attributesOriginal25b36b426f30fd196f9d947e60e48c56); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal25b36b426f30fd196f9d947e60e48c56)): ?>
<?php $component = $__componentOriginal25b36b426f30fd196f9d947e60e48c56; ?>
<?php unset($__componentOriginal25b36b426f30fd196f9d947e60e48c56); ?>
<?php endif; ?>
    </div>
    <form action="<?php echo e(route('logout')); ?>" method="POST" class="px-2 mb-3">
        <?php echo csrf_field(); ?>
        <?php if (isset($component)) { $__componentOriginal25b36b426f30fd196f9d947e60e48c56 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal25b36b426f30fd196f9d947e60e48c56 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-link','data' => ['href' => '#','class' => 'text-red-500 hover:bg-red-50 hover:text-red-600','icon' => 'logout','onclick' => 'event.preventDefault(); this.closest(\'form\').submit()']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '#','class' => 'text-red-500 hover:bg-red-50 hover:text-red-600','icon' => 'logout','onclick' => 'event.preventDefault(); this.closest(\'form\').submit()']); ?>
            Logout
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal25b36b426f30fd196f9d947e60e48c56)): ?>
<?php $attributes = $__attributesOriginal25b36b426f30fd196f9d947e60e48c56; ?>
<?php unset($__attributesOriginal25b36b426f30fd196f9d947e60e48c56); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal25b36b426f30fd196f9d947e60e48c56)): ?>
<?php $component = $__componentOriginal25b36b426f30fd196f9d947e60e48c56; ?>
<?php unset($__componentOriginal25b36b426f30fd196f9d947e60e48c56); ?>
<?php endif; ?>
    </form>
</aside>
<?php /**PATH C:\xampp\htdocs\latihan\resources\views\components\admin\sidebar.blade.php ENDPATH**/ ?>