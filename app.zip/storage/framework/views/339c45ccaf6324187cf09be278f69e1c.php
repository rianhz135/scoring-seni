

<?php $__env->startSection('content'); ?>
    <div class="mb-6">
        <h1 class="text-xl font-bold text-gray-900">Manajemen Pertandingan: Solo</h1>
        <p class="text-sm text-gray-400 mt-0.5">Kontrol status kesiapan dan mulai pertandingan per sudut.</p>
    </div>

    <div class="bg-white border border-gray-100 rounded-2xl overflow-hidden shadow-sm">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-50 border-b border-gray-100">
                        <th class="px-6 py-4 text-xs font-semibold text-gray-400 uppercase tracking-widest w-10">No</th>
                        <th class="px-6 py-4 text-xs font-semibold text-gray-400 uppercase tracking-widest w-24">Partai</th>

                        
                        <th
                            class="px-6 py-4 text-xs font-semibold text-gray-400 uppercase tracking-widest whitespace-nowrap">
                            Kelas</th>

                        <th class="px-6 py-4 text-xs font-semibold text-gray-400 uppercase tracking-widest text-center">
                            Sudut Biru (Kontrol)</th>
                        <th class="px-6 py-4 text-xs font-semibold text-gray-400 uppercase tracking-widest text-center">
                            Sudut Merah (Kontrol)</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php $__empty_1 = true; $__currentLoopData = $partais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50/50 transition-colors">
                            <td class="px-6 py-4 text-sm text-gray-600">
                                <?php echo e($partais->firstItem() + $index); ?>

                            </td>

                            <td class="px-6 py-4 font-bold text-gray-900">
                                #<?php echo e($item->no_partai); ?>

                            </td>

                            <td class="px-6 py-4 whitespace-nowrap">
                                <span
                                    class="px-2.5 py-1 rounded-md bg-primary-50 text-primary-700 text-xs font-bold uppercase border border-primary-100">
                                    
                                    <?php echo e($item->kelas->nama_kelas ?? ($item->kelas->label_kelas ?? '-')); ?>

                                </span>
                            </td>

                            
                            <?php $__currentLoopData = ['biru', 'merah']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sudut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="px-4 py-4">
                                    <?php
                                        $sudutDb = ucfirst($sudut);
                                        $detail = $item->detail_peserta->where('sudut', $sudutDb)->first();
                                    ?>

                                    <?php if($detail && $detail->peserta): ?>
                                        <div
                                            class="p-4 rounded-2xl bg-<?php echo e($sudut == 'biru' ? 'blue' : 'red'); ?>-50 border border-<?php echo e($sudut == 'biru' ? 'blue' : 'red'); ?>-100 space-y-3 <?php echo e($detail->status_mulai != 0 ? 'opacity-70' : ''); ?>">
                                            <div class="text-center">
                                                <p
                                                    class="text-sm font-bold text-<?php echo e($sudut == 'biru' ? 'blue' : 'red'); ?>-700">
                                                    <?php echo e($detail->peserta->nama_peserta); ?>

                                                </p>
                                                <p
                                                    class="text-[10px] text-<?php echo e($sudut == 'biru' ? 'blue' : 'red'); ?>-500 uppercase font-medium">
                                                    <?php echo e($detail->peserta->kontingen); ?>

                                                </p>
                                            </div>

                                            <div class="flex flex-col gap-2">
                                                <?php if($detail->status_mulai == 0): ?>
                                                    
                                                    <a href="<?php echo e(route('admin.manajemen.solo.mulai', ['id' => $item->id_partai, 'sudut' => $sudut])); ?>"
                                                        class="w-full bg-<?php echo e($sudut == 'biru' ? 'blue' : 'red'); ?>-600 hover:bg-<?php echo e($sudut == 'biru' ? 'blue' : 'red'); ?>-700 text-white py-1.5 rounded-lg text-[10px] font-extrabold transition-all flex items-center justify-center gap-1">
                                                        MULAI <?php echo e(strtoupper($sudut)); ?>

                                                    </a>
                                                <?php elseif($detail->status_mulai == 1): ?>
                                                    <button disabled
                                                        class="w-full bg-gray-300 text-white py-1.5 rounded-lg text-[10px] font-extrabold flex items-center justify-center gap-1">
                                                        RUNNING...
                                                    </button>
                                                <?php else: ?>
                                                    <button disabled
                                                        class="w-full bg-gray-200 text-gray-500 py-1.5 rounded-lg text-[10px] font-extrabold">
                                                        SELESAI
                                                    </button>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <div class="text-center text-xs text-gray-300 italic py-4">BYE / KOSONG</div>
                                    <?php endif; ?>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-6 py-12 text-center text-gray-400 italic">Data tidak ditemukan.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($partais->hasPages()): ?>
            <div class="p-4 border-t border-gray-50">
                <?php echo e($partais->links()); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\latihan\resources\views\pages\manajemen\solo\index.blade.php ENDPATH**/ ?>