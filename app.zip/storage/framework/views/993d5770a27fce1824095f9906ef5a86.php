<div class="space-y-2">

    
    <div class="rounded-lg border border-gray-200 overflow-hidden">
        <table class="w-full table-fixed text-left">
            <colgroup>
                <col style="width: 100px;">
                <col style="width: 170px;">
                <col style="width: 60px;">
                <col>
                <col style="width: 120px;">
            </colgroup>

            <thead class="bg-gray-50 text-[11px] font-bold uppercase tracking-wide text-gray-700">
                <tr>
                    <th class="px-3 py-2">Partai</th>
                    <th class="px-3 py-2">Kategori</th>
                    <th class="px-2 py-2 text-center">No</th>
                    <th class="px-3 py-2">Peserta</th>
                    <th class="px-3 py-2 text-center">Aksi</th>
                </tr>
            </thead>
        </table>
    </div>

    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php $jumlah = $partai->detail_peserta->count(); ?>

        <div class="rounded-lg border border-gray-200 overflow-hidden bg-white">
            <table class="w-full table-fixed text-left">
                <colgroup>
                    <col style="width: 100px;">
                    <col style="width: 170px;">
                    <col style="width: 60px;">
                    <col>
                    <col style="width: 120px;">
                </colgroup>

                <tbody class="divide-y divide-gray-100">

                    <?php $__currentLoopData = $partai->detail_peserta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-blue-50/40 transition">

                            <?php if($loop->first): ?>
                                
                                <td rowspan="<?php echo e($jumlah); ?>"
                                    class="px-3 py-2.5 align-middle bg-gray-50 border-r border-gray-200">

                                    <div class="text-[9px] uppercase tracking-wider text-gray-400 font-semibold">
                                        Partai
                                    </div>

                                    <div class="text-lg font-black text-gray-800 leading-tight">
                                        <?php echo e($partai->no_partai); ?>

                                    </div>

                                </td>

                                
                                <td rowspan="<?php echo e($jumlah); ?>"
                                    class="px-3 py-2.5 align-middle bg-gray-50 border-r border-gray-200">

                                    <div class="font-bold text-sm text-gray-800 leading-tight">
                                        <?php echo e($partai->kategori->nama_kategori ?? '-'); ?>

                                    </div>

                                    <div
                                        class="mt-1 inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-semibold border border-gray-200 bg-white text-gray-600">
                                        <?php echo e($partai->kelas->label_kelas ?? '-'); ?>

                                    </div>

                                </td>
                            <?php endif; ?>

                            
                            <td class="px-2 py-2 text-center align-middle">

                                <span
                                    class="inline-flex items-center justify-center w-6 h-6 text-xs font-black text-blue-700">
                                    <?php echo e($detail->no_urut ?? '-'); ?>

                                </span>

                            </td>

                            
                            <td class="px-3 py-2 align-middle">

                                <div class="text-sm font-bold text-gray-900 uppercase leading-tight">
                                    <?php echo e($detail->peserta->nama_peserta ?? '-'); ?>

                                </div>

                                <div class="text-[10px] text-blue-500 font-medium uppercase mt-0.5 leading-none">
                                    <?php echo e($detail->peserta->kontingen ?? '-'); ?>

                                </div>

                            </td>

                            
                            <td class="px-2 py-2 align-middle text-center">

                                <?php if($detail->status_mulai == 0): ?>
                                    
                                    <form
                                        action="<?php echo e(route('admin.manajemen.pool.mulai', ['id_partai' => $partai->id_partai, 'id_detail' => $detail->id_detail])); ?>"
                                        method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" style="background-color: #22c55e !important;"
                                            class="inline-flex items-center justify-center gap-1 text-white text-[11px] font-bold px-3 py-1.5 rounded-md transition-all w-full max-w-[90px] hover:opacity-90">
                                            <svg class="w-3.5 h-3.5 shrink-0" fill="none" stroke="currentColor"
                                                viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2"
                                                    d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2"
                                                    d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                            </svg>
                                            Mulai
                                        </button>
                                    </form>
                                <?php elseif($detail->status_mulai == 1): ?>
                                    
                                    <button type="button" disabled style="background-color: #3b82f6 !important;"
                                        class="inline-flex items-center justify-center gap-1 text-white text-[11px] font-bold px-3 py-1.5 rounded-md w-full max-w-[90px] cursor-not-allowed opacity-90">
                                        <svg class="w-3.5 h-3.5 animate-pulse" fill="none" stroke="currentColor"
                                            viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M13 10V3L4 14h7v7l9-11h-7z" />
                                        </svg>
                                        Berjalan
                                    </button>
                                <?php elseif($detail->status_mulai == 2): ?>
                                    
                                    <button type="button" disabled
                                        style="background-color: #6b7280 !important; color: white !important;"
                                        class="inline-flex items-center justify-center gap-1 text-[11px] font-bold px-3 py-1.5 rounded-md w-full max-w-[90px] cursor-not-allowed">
                                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor"
                                            viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3"
                                                d="M5 13l4 4L19 7" />
                                        </svg>
                                        Selesai
                                    </button>
                                <?php endif; ?>

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <div class="rounded-lg border border-gray-200 px-4 py-10 text-center text-sm italic text-gray-400">
            Belum ada antrean peserta untuk kategori ini.
        </div>

    <?php endif; ?>


    
    <?php if(method_exists($data, 'links')): ?>
        <div class="pt-2">

            <?php echo e($data->onEachSide(1)->links()); ?>


        </div>
    <?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\latihan\resources\views\pages\manajemen\pool\partials\table.blade.php ENDPATH**/ ?>