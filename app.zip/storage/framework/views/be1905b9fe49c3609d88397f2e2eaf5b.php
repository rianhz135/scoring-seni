

<?php $__env->startSection('content'); ?>
    <div class="mb-6">
        <h1 class="text-xl font-bold text-gray-900">Manajemen Pertandingan: Ganda</h1>
        <p class="text-sm text-gray-400 mt-0.5">Kontrol status kesiapan dan mulai pertandingan per sudut.</p>
    </div>

    <div class="bg-white border border-gray-100 rounded-2xl overflow-hidden shadow-sm">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-50 border-b border-gray-100">
                        <th class="px-6 py-4 text-xs font-semibold text-gray-400 uppercase tracking-widest w-10">No</th>
                        <th class="px-6 py-4 text-xs font-semibold text-gray-400 uppercase tracking-widest w-24">Partai</th>
                        <th
                            class="px-6 py-4 text-xs font-semibold text-gray-400 uppercase tracking-widest whitespace-nowrap">
                            Kelas</th>
                        <th class="px-6 py-4 text-xs font-semibold text-gray-400 uppercase tracking-widest text-center">
                            Sudut Biru (Kontrol)</th>
                        <th class="px-6 py-4 text-xs font-semibold text-gray-400 uppercase tracking-widest text-center">
                            Sudut Merah (Kontrol)</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php $__empty_1 = true; $__currentLoopData = $partais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50/50 transition-colors">
                            <td class="px-6 py-4 text-sm text-gray-600">
                                <?php echo e($partais->firstItem() + $index); ?>

                            </td>

                            <td class="px-6 py-4 font-bold text-gray-900">
                                #<?php echo e($item->no_partai); ?>

                            </td>

                            <td class="px-6 py-4 whitespace-nowrap">
                                <span
                                    class="px-2.5 py-1 rounded-md bg-primary-50 text-primary-700 text-xs font-bold uppercase border border-primary-100">
                                    <?php echo e($item->kelas->nama_kelas ?? ($item->kelas->label_kelas ?? '-')); ?>

                                </span>
                            </td>

                            
                            <?php $__currentLoopData = ['biru', 'merah']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sudut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="px-4 py-4 align-top">
                                    <?php
                                        $sudutDb = ucfirst($sudut);
                                        // PERBAIKAN: Ambil SEMUA data di sudut ini, JANGAN pakai ->first()
                                        $details = $item->detail_peserta->where('sudut', $sudutDb);

                                        // Ambil data pertama hanya untuk patokan status_mulai & kontingen
                                        $firstDetail = $details->first();
                                    ?>

                                    <?php if($details->isNotEmpty() && $firstDetail->peserta): ?>
                                        <div
                                            class="p-4 rounded-2xl bg-<?php echo e($sudut == 'biru' ? 'blue' : 'red'); ?>-50 border border-<?php echo e($sudut == 'biru' ? 'blue' : 'red'); ?>-100 space-y-4 <?php echo e($firstDetail->status_mulai != 0 ? 'opacity-70' : ''); ?>">

                                            <div class="text-center">
                                                
                                                <div class="mb-2">
                                                    <p
                                                        class="text-sm font-bold text-<?php echo e($sudut == 'biru' ? 'blue' : 'red'); ?>-700 leading-tight">
                                                        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php echo e($det->peserta->nama_peserta ?? ($det->peserta->nama ?? 'Nama Tidak Ditemukan')); ?>

                                                            <?php if(!$loop->last): ?>
                                                                &
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </p>
                                                </div>

                                                <p
                                                    class="text-[10px] text-<?php echo e($sudut == 'biru' ? 'blue' : 'red'); ?>-500 uppercase font-medium border-t border-<?php echo e($sudut == 'biru' ? 'blue' : 'red'); ?>-200 pt-2 mx-4">
                                                    <?php echo e($firstDetail->peserta->kontingen ?? '-'); ?>

                                                </p>
                                            </div>

                                            <div class="flex flex-col gap-2">
                                                <?php if($firstDetail->status_mulai == 0): ?>
                                                    
                                                    <a href="<?php echo e(route('admin.manajemen.ganda.mulai', ['id' => $item->id_partai, 'sudut' => $sudut])); ?>"
                                                        class="w-full bg-<?php echo e($sudut == 'biru' ? 'blue' : 'red'); ?>-600 hover:bg-<?php echo e($sudut == 'biru' ? 'blue' : 'red'); ?>-700 text-white py-2 rounded-lg text-[10px] font-extrabold transition-all flex items-center justify-center gap-1 shadow-sm">
                                                        MULAI <?php echo e(strtoupper($sudut)); ?>

                                                    </a>
                                                <?php elseif($firstDetail->status_mulai == 1): ?>
                                                    <button disabled
                                                        class="w-full bg-gray-300 text-white py-2 rounded-lg text-[10px] font-extrabold flex items-center justify-center gap-1 shadow-inner">
                                                        RUNNING...
                                                    </button>
                                                <?php else: ?>
                                                    <button disabled
                                                        class="w-full bg-gray-200 text-gray-500 py-2 rounded-lg text-[10px] font-extrabold shadow-inner">
                                                        SELESAI
                                                    </button>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <div
                                            class="h-full flex items-center justify-center p-4 border border-dashed border-gray-300 rounded-2xl bg-gray-50/50">
                                            <span
                                                class="text-xs text-gray-400 font-medium italic tracking-wider">KOSONG</span>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-6 py-12 text-center text-gray-400 italic">Data tidak ditemukan.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($partais->hasPages()): ?>
            <div class="p-4 border-t border-gray-50">
                <?php echo e($partais->links()); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\latihan\resources\views\pages\manajemen\ganda\index.blade.php ENDPATH**/ ?>