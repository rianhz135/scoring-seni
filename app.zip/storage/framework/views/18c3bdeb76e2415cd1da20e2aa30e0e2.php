<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['href', 'active' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['href', 'active' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<a href="<?php echo e($href); ?>" 
   class="sidebar-link flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm transition-all <?php echo e($active ? 'active' : 'text-gray-500 border-l-2 border-transparent hover:bg-gray-50 hover:text-primary-600'); ?>">
    <span class="w-1 h-1 rounded-full <?php echo e($active ? 'bg-primary-600' : 'bg-gray-300'); ?> shrink-0"></span> 
    <?php echo e($slot); ?>

</a><?php /**PATH C:\xampp\htdocs\latihan\resources\views/components/admin/sidebar-sublink.blade.php ENDPATH**/ ?>