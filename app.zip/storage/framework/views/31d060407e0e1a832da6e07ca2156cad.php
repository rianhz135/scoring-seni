<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.png')); ?>" type="image/x-icon">
    <title><?php echo e($title ?? 'Admin Panel'); ?> — DS SMI</title>


    <style>
        body {
            margin: 0;
            padding: 0;
        }

        html {
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        /* Sidebar width dikontrol penuh lewat CSS, bukan Tailwind */
        #sidebar {
            transition: width 0.3s ease;
        }

        #sidebar.collapsed {
            width: 64px !important;
        }

        /* Sembunyikan teks saat collapsed */
        #sidebar.collapsed .sidebar-link-text,
        #sidebar.collapsed .sidebar-group-text,
        #sidebar.collapsed .sidebar-chevron,
        #sidebar.collapsed .sidebar-section-label,
        #sidebar.collapsed #sidebar-brand-text {
            display: none !important;
        }

        /* Sembunyikan submenu */
        #sidebar.collapsed .nav-sub-list {
            max-height: 0 !important;
            display: none !important;
        }

        /* Center icon saat collapsed */
        #sidebar.collapsed .sidebar-link,
        #sidebar.collapsed .sidebar-group-btn {
            justify-content: center !important;
            padding-left: 0 !important;
            padding-right: 0 !important;
            gap: 0 !important;
        }

        /* Topbar & main ikut geser — pakai !important agar kalahkan Tailwind */
        #topbar {
            transition: left 0.3s ease;
            left: 240px !important;
        }

        #topbar.collapsed {
            left: 64px !important;
        }

        #main-wrapper {
            transition: margin-left 0.3s ease;
            margin-left: 240px !important;
        }

        #main-wrapper.collapsed {
            margin-left: 64px !important;
        }

        /* Dropdown */
        .nav-sub-list {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease;
        }

        .nav-sub-list.open {
            max-height: 400px;
        }

        /* Chevron */
        .chevron {
            transition: transform 0.25s ease;
        }

        .chevron.open {
            transform: rotate(90deg);
        }

        /* Active link */
        .sidebar-link.active {
            background-color: #f0f4ff;
            color: #4254e8;
            border-left-color: #4254e8;
        }
    </style>

    <script src="<?php echo e(asset('js/sweetalert2.all.min.js')); ?>"></script>
    <link rel="preload" href="/fonts/plus-jakarta-sans/static/PlusJakartaSans-Regular.woff2" as="font"
        type="font/woff2" crossorigin>
    <link rel="preload" href="/fonts/plus-jakarta-sans/static/PlusJakartaSans-Medium.woff2" as="font"
        type="font/woff2" crossorigin>
    <link rel="preload" href="/fonts/plus-jakarta-sans/static/PlusJakartaSans-SemiBold.woff2" as="font"
        type="font/woff2" crossorigin>
    <link rel="preload" href="/fonts/plus-jakarta-sans/static/PlusJakartaSans-Bold.woff2" as="font"
        type="font/woff2" crossorigin>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="bg-gray-50 text-gray-800 font-sans antialiased">
    <div class="flex min-h-screen">

        <?php if (isset($component)) { $__componentOriginalbebe114f3ccde4b38d7462a3136be045 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbebe114f3ccde4b38d7462a3136be045 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbebe114f3ccde4b38d7462a3136be045)): ?>
<?php $attributes = $__attributesOriginalbebe114f3ccde4b38d7462a3136be045; ?>
<?php unset($__attributesOriginalbebe114f3ccde4b38d7462a3136be045); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbebe114f3ccde4b38d7462a3136be045)): ?>
<?php $component = $__componentOriginalbebe114f3ccde4b38d7462a3136be045; ?>
<?php unset($__componentOriginalbebe114f3ccde4b38d7462a3136be045); ?>
<?php endif; ?>

        <div id="main-wrapper" class="flex-1 flex flex-col min-h-screen">
            <?php if (isset($component)) { $__componentOriginal232f012cda936a4eb249de3234ccfddd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal232f012cda936a4eb249de3234ccfddd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.topbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal232f012cda936a4eb249de3234ccfddd)): ?>
<?php $attributes = $__attributesOriginal232f012cda936a4eb249de3234ccfddd; ?>
<?php unset($__attributesOriginal232f012cda936a4eb249de3234ccfddd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal232f012cda936a4eb249de3234ccfddd)): ?>
<?php $component = $__componentOriginal232f012cda936a4eb249de3234ccfddd; ?>
<?php unset($__componentOriginal232f012cda936a4eb249de3234ccfddd); ?>
<?php endif; ?>

            <main class="flex-1 p-7 pt-20">
                <?php echo $__env->yieldContent('content'); ?>
            </main>

            <footer class="bg-white p-4 border-t text-center text-sm text-gray-500">
                &copy; <?php echo e(date('Y')); ?> Admin Panel - Sistem Pertandingan
            </footer>
        </div>
    </div>

    <script>
        const STORAGE_KEY = 'sidebar_collapsed';

        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const wrapper = document.getElementById('main-wrapper');
            const topbar = document.getElementById('topbar');
            const isCollapsed = sidebar.classList.toggle('collapsed');
            wrapper.classList.toggle('collapsed', isCollapsed);
            topbar.classList.toggle('collapsed', isCollapsed);
            localStorage.setItem(STORAGE_KEY, isCollapsed ? '1' : '0');
        }

        // Restore state sebelum render agar tidak flash
        (function() {
            if (localStorage.getItem(STORAGE_KEY) === '1') {
                ['sidebar', 'main-wrapper', 'topbar'].forEach(function(id) {
                    var el = document.getElementById(id);
                    if (el) el.classList.add('collapsed');
                });
            }
        })();

        function toggleSection(id) {
            if (document.getElementById('sidebar').classList.contains('collapsed')) return;
            var subs = document.getElementById('subs-' + id);
            var chevron = document.getElementById('chevron-' + id);
            if (subs) subs.classList.toggle('open');
            if (chevron) chevron.classList.toggle('open');
        }

        document.addEventListener('DOMContentLoaded', function() {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer);
                    toast.addEventListener('mouseleave', Swal.resumeTimer);
                }
            });
            <?php if(session('success')): ?>
                Toast.fire({
                    icon: 'success',
                    title: "<?php echo session('success'); ?>"
                });
            <?php endif; ?>
            <?php if(session('error')): ?>
                Toast.fire({
                    icon: 'error',
                    title: "<?php echo session('error'); ?>"
                });
            <?php endif; ?>
        });
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\latihan\resources\views\layouts\admin.blade.php ENDPATH**/ ?>