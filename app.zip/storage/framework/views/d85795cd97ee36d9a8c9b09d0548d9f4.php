<!DOCTYPE html>
<html>

<head>
    <title>Laporan Hasil Solo</title>
    <style>
        @page {
            margin: 1cm;
            size: a4 landscape;
        }

        body {
            font-family: 'Helvetica', sans-serif;
            font-size: 8.5pt;
            color: #333;
            line-height: 1.1;
        }

        .header {
            text-align: center;
            margin-bottom: 15px;
            border-bottom: 2px solid #2c3e50;
            padding-bottom: 5px;
        }

        .header h1 {
            margin: 0;
            text-transform: uppercase;
            font-size: 14pt;
        }

        table.main-table {
            width: 100%;
            border-collapse: collapse;
        }

        table.main-table th {
            background-color: #f8fafc;
            border: 1px solid #cbd5e1;
            padding: 6px;
            font-size: 8pt;
            text-transform: uppercase;
        }

        /* Mengecilkan padding td agar tinggi kolom menyusut */
        table.main-table td {
            border: 1px solid #cbd5e1;
            padding: 3px 5px;
            vertical-align: middle;
        }

        .text-center {
            text-align: center;
        }

        /* Table pembungkus kiri-kanan */
        table.wrapper-komparasi {
            width: 100%;
            border-collapse: collapse;
            margin: 0;
        }

        table.wrapper-komparasi td {
            border: none !important;
            padding: 0 !important;
            width: 50%;
            vertical-align: top;
        }

        /* Kotak Sudut - Diperketat */
        .box-sudut {
            padding: 4px 6px;
            border-radius: 3px;
            margin: 2px;
        }

        .sudut-biru {
            background-color: #f0f9ff;
            border: 1px solid #bae6fd;
        }

        .sudut-merah {
            background-color: #fef2f2;
            border: 1px solid #fecaca;
        }

        /* Inner Table untuk Nama & Total */
        table.inner-table {
            width: 100%;
            border-collapse: collapse;
        }

        table.inner-table td {
            border: none !important;
            padding: 0 !important;
        }

        .nama {
            font-weight: bold;
            font-size: 9pt;
            text-transform: uppercase;
            color: #1e293b;
        }

        .kontingen {
            font-size: 7pt;
            color: #64748b;
            font-style: italic;
            display: block;
            margin-bottom: 2px;
        }

        .stats {
            font-size: 6.5pt;
            color: #475569;
        }

        .total-nilai {
            font-size: 13pt;
            font-weight: bold;
        }

        .text-biru {
            color: #0369a1;
        }

        .text-merah {
            color: #b91c1c;
        }

        .badge-disq {
            background: #fee2e2;
            color: #b91c1c;
            padding: 1px 4px;
            border: 1px solid #fca5a5;
            font-size: 7pt;
            font-weight: bold;
        }

        .badge-pemenang {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 8pt;
            font-weight: bold;
            color: #ffffff;
            text-transform: uppercase;
        }

        .bg-pemenang-biru {
            background-color: #2563eb;
        }

        /* Biru yang lebih solid untuk PDF */
        .bg-pemenang-merah {
            background-color: #dc2626;
        }

        /* Merah yang lebih solid untuk PDF */
        .text-muted {
            color: #94a3b8;
            font-style: italic;
            font-size: 8pt;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Rekapitulasi Hasil Pertandingan Solo</h1>
        <p>Cetak: <?php echo e(date('d/m/Y H:i')); ?></p>
    </div>

    <table class="main-table">
        <thead>
            <tr>
                <th style="width: 30px;">No</th>
                <th style="width: 50px;">Partai</th>
                <th style="width: 100px;">Kelas</th>
                <th>Komparasi Nilai Sudut</th>
                <th style="width: 100px;">Pemenang</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $partais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $partai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $biru =
                        $partai->detail_peserta->firstWhere('sudut', 'Biru') ??
                        $partai->detail_peserta->firstWhere('sudut', 'biru');
                    $merah =
                        $partai->detail_peserta->firstWhere('sudut', 'Merah') ??
                        $partai->detail_peserta->firstWhere('sudut', 'merah');
                    $isDisqBiru = ($biru->is_disqualifikasi ?? ($biru->is_disqulifikasi ?? 0)) == 1;
                    $isDisqMerah = ($merah->is_disqualifikasi ?? ($merah->is_disqulifikasi ?? 0)) == 1;
                ?>
                <tr>
                    <td class="text-center"><?php echo e($index + 1); ?></td>
                    <td class="text-center font-bold"><?php echo e($partai->no_partai); ?></td>
                    <td class="text-center"><?php echo e($partai->kelas->label_kelas ?? '-'); ?></td>
                    <td>
                        <table class="wrapper-komparasi">
                            <tr>
                                
                                <td class="td-kiri">
                                    <?php if($biru): ?>
                                        <div class="box-sudut sudut-biru">
                                            <table class="inner-table">
                                                <tr>
                                                    <td>
                                                        <span class="nama text-biru">
                                                            
                                                            <?php echo e($biru->peserta->nama ?? ($biru->peserta->nama_peserta ?? ($biru->peserta->nama_lengkap ?? 'Tanpa Nama'))); ?>

                                                        </span>
                                                        <span
                                                            class="kontingen">(<?php echo e($biru->peserta->kontingen ?? '-'); ?>)</span>
                                                        <?php if($isDisqBiru): ?>
                                                            <span class="badge-disq">DISQ</span>
                                                        <?php else: ?>
                                                            <div class="stats">
                                                                M: <?php echo e(number_format($biru->nilai_median, 2)); ?> |
                                                                D: <?php echo e($biru->nilai_deviasi); ?> |
                                                                H: <?php echo e(number_format($biru->hukuman_ketua, 1)); ?> |
                                                                W: <?php echo e(floor(($biru->waktu_tampil ?? 0) / 60)); ?>:<?php echo e(str_pad(($biru->waktu_tampil ?? 0) % 60, 2, '0', STR_PAD_LEFT)); ?>

                                                            </div>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td style="text-align: right; width: 45px; vertical-align: middle;">
                                                        <?php if(!$isDisqBiru): ?>
                                                            <span
                                                                class="total-nilai text-biru"><?php echo e(number_format($biru->total_nilai, 3)); ?></span>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            </table>
                                        </div>
                                    <?php endif; ?>
                                </td>

                                
                                <td class="td-kanan">
                                    <?php if($merah): ?>
                                        <div class="box-sudut sudut-merah">
                                            <table class="inner-table">
                                                <tr>
                                                    <td>
                                                        <span class="nama text-merah">
                                                            
                                                            <?php echo e($merah->peserta->nama ?? ($merah->peserta->nama_peserta ?? ($merah->peserta->nama_lengkap ?? 'Tanpa Nama'))); ?>

                                                        </span>
                                                        <span
                                                            class="kontingen">(<?php echo e($merah->peserta->kontingen ?? '-'); ?>)</span>
                                                        <?php if($isDisqMerah): ?>
                                                            <span class="badge-disq">DISQ</span>
                                                        <?php else: ?>
                                                            <div class="stats">
                                                                M: <?php echo e(number_format($merah->nilai_median, 2)); ?> |
                                                                D: <?php echo e($merah->nilai_deviasi); ?> |
                                                                H: <?php echo e(number_format($merah->hukuman_ketua, 1)); ?> |
                                                                W: <?php echo e(floor(($merah->waktu_tampil ?? 0) / 60)); ?>:<?php echo e(str_pad(($merah->waktu_tampil ?? 0) % 60, 2, '0', STR_PAD_LEFT)); ?>

                                                            </div>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td style="text-align: right; width: 45px; vertical-align: middle;">
                                                        <?php if(!$isDisqMerah): ?>
                                                            <span
                                                                class="total-nilai text-merah"><?php echo e(number_format($merah->total_nilai, 3)); ?></span>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            </table>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </table>
                    </td>
                    <td class="text-center">
                        <?php
                            // Mencari peserta yang memiliki status is_pemenang = 1
                            $pemenang = $partai->detail_peserta->firstWhere('is_pemenang', 1);
                        ?>

                        <?php if($pemenang): ?>
                            <span
                                class="badge-pemenang <?php echo e(strtolower($pemenang->sudut) == 'biru' ? 'bg-pemenang-biru' : 'bg-pemenang-merah'); ?>">
                                <?php echo e(strtoupper($pemenang->sudut)); ?>

                            </span>
                        <?php else: ?>
                            <span class="text-muted">BELUM DITETAPKAN</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\latihan\resources\views\pages\hasil\solo\pdf.blade.php ENDPATH**/ ?>