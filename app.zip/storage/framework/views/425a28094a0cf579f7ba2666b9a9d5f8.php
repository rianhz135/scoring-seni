

<?php $__env->startSection('content'); ?>
    <div class="mb-6 flex justify-between items-center">
        <div>
            <h1 class="text-2xl font-bold text-gray-900">Tambah Peserta Tunggal</h1>
            <p class="text-sm text-gray-500 mt-1">Input data partai dan atlet yang akan bertanding.</p>
        </div>
        <a href="<?php echo e(route('admin.peserta.tunggal.index')); ?>"
            class="text-gray-600 hover:text-gray-900 flex items-center gap-2 text-sm font-semibold transition-all">
            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Kembali ke Daftar
        </a>
    </div>

    
    <form action="<?php echo e(route('admin.peserta.tunggal.store')); ?>" method="POST" class="space-y-6">
        <?php echo csrf_field(); ?>

        <div class="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm">
            <div class="flex items-center gap-3 mb-6">
                <div class="p-2 bg-primary-50 rounded-lg text-primary-600">
                    <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                </div>
                <h2 class="text-lg font-bold text-gray-900">Informasi Pertandingan</h2>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="space-y-2">
                    <label class="text-sm font-bold text-gray-700">Nomor Partai</label>
                    <input type="text" name="no_partai" value="<?php echo e(old('no_partai')); ?>" placeholder="Contoh: 1"
                        class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all text-sm">
                    <?php $__errorArgs = ['no_partai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1 font-bold"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="space-y-2">
                    <label class="text-sm font-bold text-gray-700">Kelas</label>
                    <select name="id_kelas"
                        class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all text-sm bg-white">
                        <option value="">-- Pilih Kelas --</option>
                        <?php $__currentLoopData = $data_kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kelas->id_kelas); ?>"
                                <?php echo e(old('id_kelas') == $kelas->id_kelas ? 'selected' : ''); ?>>
                                <?php echo e($kelas->label_kelas); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['id_kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1 font-bold"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>

        
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

            <div class="bg-white border border-blue-100 rounded-2xl p-6 shadow-sm relative overflow-hidden">
                <div class="absolute top-0 right-0 w-24 h-24 bg-blue-50 -mr-8 -mt-8 rounded-full opacity-50"></div>

                <div class="flex items-center gap-3 mb-6 relative">
                    <div class="p-2 bg-blue-600 rounded-lg text-white shadow-md shadow-blue-200">
                        <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                            <path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                    </div>
                    <h2 class="text-lg font-bold text-blue-700 uppercase tracking-tight">SUDUT BIRU</h2>
                </div>

                <div class="space-y-4 relative">
                    <div class="space-y-2">
                        <label class="text-xs font-bold text-blue-600 uppercase">Nama Peserta</label>
                        <input type="text" name="biru_nama" value="<?php echo e(old('biru_nama')); ?>"
                            placeholder="Nama lengkap atlet..."
                            class="w-full px-4 py-2.5 rounded-xl border border-blue-100 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition-all text-sm">
                    </div>
                    <div class="space-y-2">
                        <label class="text-xs font-bold text-blue-600 uppercase">Kontingen</label>
                        <input type="text" name="biru_kontingen" value="<?php echo e(old('biru_kontingen')); ?>"
                            placeholder="Provinsi / Kabupaten..."
                            class="w-full px-4 py-2.5 rounded-xl border border-blue-100 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition-all text-sm">
                    </div>
                </div>
            </div>

            <div class="bg-white border border-red-100 rounded-2xl p-6 shadow-sm relative overflow-hidden">
                <div class="absolute top-0 right-0 w-24 h-24 bg-red-50 -mr-8 -mt-8 rounded-full opacity-50"></div>

                <div class="flex items-center gap-3 mb-6 relative">
                    <div class="p-2 bg-red-600 rounded-lg text-white shadow-md shadow-red-200">
                        <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                            <path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                    </div>
                    <h2 class="text-lg font-bold text-red-700 uppercase tracking-tight">SUDUT MERAH</h2>
                </div>

                <div class="space-y-4 relative">
                    <div class="space-y-2">
                        <label class="text-xs font-bold text-red-600 uppercase">Nama Peserta</label>
                        <input type="text" name="merah_nama" value="<?php echo e(old('merah_nama')); ?>"
                            placeholder="Nama lengkap atlet..."
                            class="w-full px-4 py-2.5 rounded-xl border border-red-100 focus:border-red-500 focus:ring-2 focus:ring-red-100 outline-none transition-all text-sm">
                    </div>
                    <div class="space-y-2">
                        <label class="text-xs font-bold text-red-600 uppercase">Kontingen</label>
                        <input type="text" name="merah_kontingen" value="<?php echo e(old('merah_kontingen')); ?>"
                            placeholder="Provinsi / Kabupaten..."
                            class="w-full px-4 py-2.5 rounded-xl border border-red-100 focus:border-red-500 focus:ring-2 focus:ring-red-100 outline-none transition-all text-sm">
                    </div>
                </div>
            </div>
        </div>

        <div class="flex items-center justify-end gap-4 pt-4">
            <button type="reset" class="px-6 py-2.5 text-sm font-bold text-gray-500 hover:text-gray-700 transition-all">
                Reset Form
            </button>
            <button type="submit"
                class="bg-primary-600 hover:bg-primary-700 text-white px-8 py-2.5 rounded-xl text-sm font-bold shadow-lg shadow-primary-100 transition-all">
                Simpan Data Peserta
            </button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\latihan\resources\views\pages\peserta\tunggal\create.blade.php ENDPATH**/ ?>