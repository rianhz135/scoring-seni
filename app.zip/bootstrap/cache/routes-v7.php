<?php

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/_ignition/health-check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.healthCheck',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/execute-solution' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.executeSolution',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/update-config' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.updateConfig',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/up' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mHUBOWSeCc9c0wG0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'login.process',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dewan/display' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dewan.display',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2O4gNxe22jvsj0M5',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dewan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YjiYcIlIdHwCdMgy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.profile',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dewan/solo/refresh-display' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dewan.solo.refresh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dewan/ganda/refresh-display' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dewan.ganda.refresh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dewan/tunggal/refresh-display' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dewan.tunggal.refresh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dewan/regu/refresh-display' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dewan.regu.refresh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dewan/pool/refresh' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dewan.pool.refresh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/peserta/solo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.solo.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/peserta/solo/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.solo.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/peserta/solo/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.solo.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/peserta/pool' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.pool.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/peserta/pool/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.pool.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/peserta/pool/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.pool.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/peserta/ganda' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.ganda.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/peserta/ganda/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.ganda.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/peserta/ganda/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.ganda.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/peserta/tunggal' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.tunggal.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/peserta/tunggal/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.tunggal.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/peserta/regu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.regu.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/peserta/regu/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.regu.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/peserta/regu/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.regu.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/manajemen/solo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.solo.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/manajemen/ganda' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.ganda.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/manajemen/tunggal' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.tunggal.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/manajemen/regu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.regu.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/manajemen/kelas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.kelas.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.kelas.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/manajemen/kelas/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.kelas.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/manajemen/pool' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.pool.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/hasil/solo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.hasil.solo.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/hasil/solo/export-pdf' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.hasil.solo.export-pdf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/hasil/ganda' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.hasil.ganda.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/hasil/ganda/export-pdf' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.hasil.ganda.export-pdf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/hasil/tunggal' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.hasil.tunggal.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/hasil/tunggal/export-pdf' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.hasil.tunggal.export-pdf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/hasil/regu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.hasil.regu.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/hasil/regu/export-pdf' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.hasil.regu.export-pdf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/hasil/pool' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.hasil.pool.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/hasil/pool/export-pdf' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.hasil.pool.export-pdf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cek-partai-aktif' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nJYB02l72hdgy9v0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/juri/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'juri.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/reset/semua' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.reset.semua',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/broadcasting/auth' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mkA7Gva2fToIb2Qb',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/admin/(?|dewan/(?|solo/([^/]++)/selesai/([^/]++)(*:56)|ganda/([^/]++)/selesai/([^/]++)(*:94)|tunggal/([^/]++)/selesai/([^/]++)(*:134)|regu/([^/]++)/selesai/([^/]++)(*:172)|pool/([^/]++)/selesai/([^/]++)(*:210))|peserta/(?|solo/([^/]++)(?|/edit(*:251)|(*:259))|pool/([^/]++)(?|/edit(*:289)|(*:297))|ganda/([^/]++)(?|/edit(*:328)|(*:336))|tunggal/(?|([^/]++)(?|/edit(*:372)|(*:380))|store(*:394)|([^/]++)(*:410))|regu/([^/]++)(?|/edit(*:440)|(*:448)))|manajemen/(?|solo/(?|mulai/([^/]++)/([^/]++)(*:502)|hukuman/([^/]++)/([^/]++)(*:535)|diskualifikasi/([^/]++)/([^/]++)(*:575)|update\\-timer/([^/]++)/([^/]++)(*:614)|get\\-(?|status/([^/]++)/([^/]++)(*:654)|juri\\-scores/([^/]++)/([^/]++)(*:692))|toggle\\-(?|juri/([^/]++)/([^/]++)(*:734)|status\\-input/([^/]++)/([^/]++)(*:773)))|ganda/(?|mulai/([^/]++)/([^/]++)(*:815)|hukuman/([^/]++)/([^/]++)(*:848)|diskualifikasi/([^/]++)/([^/]++)(*:888)|update\\-timer/([^/]++)/([^/]++)(*:927)|get\\-(?|status/([^/]++)/([^/]++)(*:967)|juri\\-scores/([^/]++)/([^/]++)(*:1005))|toggle\\-(?|juri/([^/]++)/([^/]++)(*:1048)|status\\-input/([^/]++)/([^/]++)(*:1088)))|tunggal/(?|mulai/([^/]++)/([^/]++)(*:1133)|hukuman/([^/]++)/([^/]++)(*:1167)|diskualifikasi/([^/]++)/([^/]++)(*:1208)|update\\-timer/([^/]++)/([^/]++)(*:1248)|get\\-(?|status/([^/]++)/([^/]++)(*:1289)|juri\\-scores/([^/]++)/([^/]++)(*:1328))|toggle\\-(?|juri/([^/]++)/([^/]++)(*:1371)|status\\-input/([^/]++)/([^/]++)(*:1411)))|regu/(?|mulai/([^/]++)/([^/]++)(*:1453)|hukuman/([^/]++)/([^/]++)(*:1487)|diskualifikasi/([^/]++)/([^/]++)(*:1528)|update\\-timer/([^/]++)/([^/]++)(*:1568)|get\\-(?|status/([^/]++)/([^/]++)(*:1609)|juri\\-scores/([^/]++)/([^/]++)(*:1648))|toggle\\-(?|juri/([^/]++)/([^/]++)(*:1691)|status\\-input/([^/]++)/([^/]++)(*:1731)))|pool/([^/]++)/mulai/([^/]++)(*:1770)|kelas/([^/]++)(?|(*:1796)|/edit(*:1810)|(*:1819)|(*:1828)))|hasil/(?|solo/([^/]++)/t(?|etapkan\\-pemenang(*:1883)|utup\\-display(*:1905))|ganda/([^/]++)/t(?|etapkan\\-pemenang(*:1951)|utup\\-display(*:1973))|tunggal/([^/]++)/t(?|etapkan\\-pemenang(*:2021)|utup\\-display(*:2043))|regu/([^/]++)/t(?|etapkan\\-pemenang(*:2088)|utup\\-display(*:2110))|pool/([^/]++)/t(?|etapkan\\-pemenang(*:2155)|utup\\-display(*:2177))))|/juri/(?|solo(?|/(?|([^/]++)(*:2217)|simpan/([^/]++)/([^/]++)(*:2250))|\\-ganda/(?|([^/]++)(*:2279)|simpan/([^/]++)/([^/]++)(*:2312)))|ganda/(?|([^/]++)(*:2340)|simpan/([^/]++)/([^/]++)(*:2373))|tunggal/(?|([^/]++)(*:2402)|input\\-nilai/([^/]++)/([^/]++)/([^/]++)(*:2450)|s(?|impan\\-nilai/([^/]++)/([^/]++)(*:2493)|elesai/([^/]++)/([^/]++)(*:2526)))|regu/(?|([^/]++)(*:2553)|input\\-nilai/([^/]++)/([^/]++)/([^/]++)(*:2601)|simpan\\-nilai/([^/]++)/([^/]++)(*:2641)))|/dewan/(?|solo/([^/]++)/([^/]++)(*:2684)|ganda/([^/]++)/([^/]++)(*:2716)|tunggal/([^/]++)/([^/]++)(*:2750)|regu/([^/]++)/([^/]++)(*:2781)|pool/(?|([^/]++)(?|(*:2809)|/(?|diskualifikasi/([^/]++)(*:2845)|selesai/([^/]++)(*:2870)))|update\\-(?|hukuman(*:2899)|timer/([^/]++)/([^/]++)(*:2931))|hukuman/([^/]++)/([^/]++)(*:2966)|toggle\\-(?|juri/([^/]++)/([^/]++)(*:3008)|status\\-input/([^/]++)/([^/]++)(*:3048)))))/?$}sDu',
    ),
    3 => 
    array (
      56 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dewan.solo.selesai',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      94 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dewan.ganda.selesai',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      134 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dewan.tunggal.selesai',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      172 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dewan.regu.selesai',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      210 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dewan.pool.selesai',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'id_detail',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      251 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.solo.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      259 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.solo.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.solo.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      289 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.pool.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      297 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.pool.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.pool.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      328 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.ganda.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      336 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.ganda.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.ganda.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      372 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.tunggal.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      380 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.tunggal.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      394 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.tunggal.store',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      410 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.tunggal.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      440 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.regu.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      448 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.regu.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.peserta.regu.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      502 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.solo.mulai',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      535 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.solo.hukuman',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      575 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.solo.diskualifikasi',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      614 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.solo.update-timer',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      654 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      692 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.generated::m6mFihxTqHJLcFCG',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      734 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.generated::OS5O4LNnFKjV0VZZ',
          ),
          1 => 
          array (
            0 => 'id_partai',
            1 => 'no_juri',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      773 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.generated::zir0oUX8mpFNTb5J',
          ),
          1 => 
          array (
            0 => 'id_partai',
            1 => 'no_juri',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      815 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.ganda.mulai',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      848 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.ganda.hukuman',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      888 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.ganda.diskualifikasi',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      927 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.ganda.update-timer',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      967 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.generated::haexRyRNb8ulU36b',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1005 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.generated::4yBHvTfXlwC2N2k2',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1048 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.generated::utzrETRWeTPeGiYM',
          ),
          1 => 
          array (
            0 => 'id_partai',
            1 => 'no_juri',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1088 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.generated::XgrVYQ7FrayrHWCo',
          ),
          1 => 
          array (
            0 => 'id_partai',
            1 => 'no_juri',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1133 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.tunggal.mulai',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1167 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.tunggal.hukuman',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1208 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.tunggal.diskualifikasi',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1248 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.tunggal.update-timer',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1289 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.generated::B2HbcRKZcGLvRlmb',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1328 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.generated::i3cfojz1ek2WrJ2I',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1371 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.generated::ENNzXWhx1PWKT9rG',
          ),
          1 => 
          array (
            0 => 'id_partai',
            1 => 'no_juri',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1411 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.generated::ZKSfNjzHySPWvdBl',
          ),
          1 => 
          array (
            0 => 'id_partai',
            1 => 'no_juri',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1453 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.regu.mulai',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1487 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.regu.hukuman',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1528 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.regu.diskualifikasi',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1568 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.regu.update-timer',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1609 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.generated::aiv7pVAswt1j3vxY',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1648 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.generated::otHkUF56iEoYfN4Y',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1691 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.generated::qUK2fFTqjGTicRig',
          ),
          1 => 
          array (
            0 => 'id_partai',
            1 => 'no_juri',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1731 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.generated::lCgB58lwRuUF7WpW',
          ),
          1 => 
          array (
            0 => 'id_partai',
            1 => 'no_juri',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1770 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.pool.mulai',
          ),
          1 => 
          array (
            0 => 'id_partai',
            1 => 'id_detail',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1796 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.kelas.show',
          ),
          1 => 
          array (
            0 => 'kela',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1810 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.kelas.edit',
          ),
          1 => 
          array (
            0 => 'kela',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1819 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.kelas.update',
          ),
          1 => 
          array (
            0 => 'kela',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.kelas.destroy',
          ),
          1 => 
          array (
            0 => 'kela',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1828 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.admin.manajemen.kelas.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.manajemen.admin.manajemen.kelas.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1883 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.hasil.solo.tetapkan-pemenang',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1905 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.hasil.solo.tutup-display',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1951 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.hasil.ganda.tetapkan-pemenang',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1973 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.hasil.ganda.tutup-display',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2021 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.hasil.tunggal.tetapkan-pemenang',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2043 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.hasil.tunggal.tutup-display',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2088 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.hasil.regu.tetapkan-pemenang',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2110 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.hasil.regu.tutup-display',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2155 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.hasil.pool.tetapkan',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2177 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.hasil.pool.tutup',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2217 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'juri.solo',
          ),
          1 => 
          array (
            0 => 'no_juri',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2250 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'juri.solo.simpan',
          ),
          1 => 
          array (
            0 => 'id_detail',
            1 => 'no_juri',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2279 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'juri.solo-ganda',
          ),
          1 => 
          array (
            0 => 'no_juri',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2312 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'juri.solo-ganda.simpan',
          ),
          1 => 
          array (
            0 => 'id_detail',
            1 => 'no_juri',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2340 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'juri.ganda',
          ),
          1 => 
          array (
            0 => 'no_juri',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2373 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'juri.ganda.simpan',
          ),
          1 => 
          array (
            0 => 'id_detail',
            1 => 'no_juri',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2402 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'juri.tunggal',
          ),
          1 => 
          array (
            0 => 'no_juri',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2450 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'juri.tunggal.input-nilai',
          ),
          1 => 
          array (
            0 => 'id_partai',
            1 => 'no_juri',
            2 => 'sudut',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2493 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'juri.tunggal.simpan-nilai-final',
          ),
          1 => 
          array (
            0 => 'id_detail',
            1 => 'no_juri',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2526 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'juri.tunggal.selesai',
          ),
          1 => 
          array (
            0 => 'id_partai',
            1 => 'sudut',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2553 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'juri.regu',
          ),
          1 => 
          array (
            0 => 'no_juri',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2601 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'juri.regu.input-nilai',
          ),
          1 => 
          array (
            0 => 'id_partai',
            1 => 'no_juri',
            2 => 'sudut',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2641 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'juri.regu.simpan-nilai-final',
          ),
          1 => 
          array (
            0 => 'id_detail',
            1 => 'no_juri',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2684 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dewan.solo',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2716 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dewan.ganda',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2750 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dewan.tunggal',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2781 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dewan.regu',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'sudut',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2809 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dewan.pool.index',
          ),
          1 => 
          array (
            0 => 'id_partai',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2845 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dewan.pool.diskualifikasi',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'id_detail',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2870 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dewan.pool.selesai',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'id_detail',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2899 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dewan.pool.update-hukuman',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2931 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dewan.pool.update-timer',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'id_detail',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2966 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dewan.pool.hukuman',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'id_detail',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3008 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dewan.pool.toggle-juri',
          ),
          1 => 
          array (
            0 => 'id_partai',
            1 => 'no_juri',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3048 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dewan.pool.toggle-status-input',
          ),
          1 => 
          array (
            0 => 'id_partai',
            1 => 'no_juri',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'ignition.healthCheck' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/health-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController',
        'as' => 'ignition.healthCheck',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.executeSolution' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/execute-solution',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController',
        'as' => 'ignition.executeSolution',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.updateConfig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/update-config',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController',
        'as' => 'ignition.updateConfig',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mHUBOWSeCc9c0wG0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'up',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:827:"function () {
                    $exception = null;

                    try {
                        \\Illuminate\\Support\\Facades\\Event::dispatch(new \\Illuminate\\Foundation\\Events\\DiagnosingHealth);
                    } catch (\\Throwable $e) {
                        if (app()->hasDebugModeEnabled()) {
                            throw $e;
                        }

                        report($e);

                        $exception = $e->getMessage();
                    }

                    return response(\\Illuminate\\Support\\Facades\\View::file(\'C:\\\\xampp\\\\htdocs\\\\latihan\\\\vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Foundation\\\\Configuration\'.\'/../resources/health-up.blade.php\', [
                        \'exception\' => $exception,
                    ]), status: $exception ? 500 : 200);
                }";s:5:"scope";s:54:"Illuminate\\Foundation\\Configuration\\ApplicationBuilder";s:4:"this";N;s:4:"self";s:32:"00000000000005760000000000000000";}}',
        'as' => 'generated::mHUBOWSeCc9c0wG0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@index',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login.process' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@authenticate',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@authenticate',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login.process',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dewan.display' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dewan/display',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:280:"function () {

    $partai = \\App\\Models\\Partai::with([\'kelas\', \'detail_peserta.peserta\'])
        ->whereHas(\'detail_peserta\', function ($q) {
            $q->where(\'status_mulai\', 1);
        })
        ->first();

    return \\view(\'pages.dewan.display\', \\compact(\'partai\'));

}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000057d0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'dewan.display',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2O4gNxe22jvsj0M5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:55:"function () {
    return \\redirect()->route(\'login\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000057f0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::2O4gNxe22jvsj0M5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YjiYcIlIdHwCdMgy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dewan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:54:"function () {
    return \\view(\'pages.dewan.index\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000005810000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::YjiYcIlIdHwCdMgy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\DashboardController@index',
        'as' => 'admin.dashboard',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.profile' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProfileController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProfileController@index',
        'as' => 'admin.profile',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dewan.solo.selesai' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/dewan/solo/{id}/selesai/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@selesai',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@selesai',
        'as' => 'admin.dewan.solo.selesai',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dewan.ganda.selesai' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/dewan/ganda/{id}/selesai/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@selesai',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@selesai',
        'as' => 'admin.dewan.ganda.selesai',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dewan.tunggal.selesai' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/dewan/tunggal/{id}/selesai/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@selesai',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@selesai',
        'as' => 'admin.dewan.tunggal.selesai',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dewan.regu.selesai' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/dewan/regu/{id}/selesai/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@selesai',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@selesai',
        'as' => 'admin.dewan.regu.selesai',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dewan.pool.selesai' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/dewan/pool/{id}/selesai/{id_detail}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@selesai',
        'controller' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@selesai',
        'as' => 'admin.dewan.pool.selesai',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dewan.solo.refresh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/dewan/solo/refresh-display',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@triggerRefreshDisplay',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@triggerRefreshDisplay',
        'as' => 'admin.dewan.solo.refresh',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dewan.ganda.refresh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/dewan/ganda/refresh-display',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@triggerRefreshDisplay',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@triggerRefreshDisplay',
        'as' => 'admin.dewan.ganda.refresh',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dewan.tunggal.refresh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/dewan/tunggal/refresh-display',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@triggerRefreshDisplay',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@triggerRefreshDisplay',
        'as' => 'admin.dewan.tunggal.refresh',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dewan.regu.refresh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/dewan/regu/refresh-display',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@triggerRefreshDisplay',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@triggerRefreshDisplay',
        'as' => 'admin.dewan.regu.refresh',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dewan.pool.refresh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/dewan/pool/refresh',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@triggerRefreshDisplay',
        'controller' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@triggerRefreshDisplay',
        'as' => 'admin.dewan.pool.refresh',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.solo.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/peserta/solo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\SoloController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\SoloController@index',
        'as' => 'admin.peserta.solo.index',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/solo',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.solo.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/peserta/solo/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\SoloController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\SoloController@create',
        'as' => 'admin.peserta.solo.create',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/solo',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.solo.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/peserta/solo/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\SoloController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\SoloController@store',
        'as' => 'admin.peserta.solo.store',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/solo',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.solo.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/peserta/solo/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\SoloController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\SoloController@edit',
        'as' => 'admin.peserta.solo.edit',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/solo',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.solo.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/peserta/solo/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\SoloController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\SoloController@update',
        'as' => 'admin.peserta.solo.update',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/solo',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.solo.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/peserta/solo/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\SoloController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\SoloController@destroy',
        'as' => 'admin.peserta.solo.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/solo',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.pool.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/peserta/pool',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\PoolController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\PoolController@index',
        'as' => 'admin.peserta.pool.index',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/pool',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.pool.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/peserta/pool/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\PoolController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\PoolController@create',
        'as' => 'admin.peserta.pool.create',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/pool',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.pool.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/peserta/pool/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\PoolController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\PoolController@store',
        'as' => 'admin.peserta.pool.store',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/pool',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.pool.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/peserta/pool/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\PoolController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\PoolController@edit',
        'as' => 'admin.peserta.pool.edit',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/pool',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.pool.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/peserta/pool/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\PoolController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\PoolController@update',
        'as' => 'admin.peserta.pool.update',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/pool',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.pool.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/peserta/pool/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\PoolController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\PoolController@destroy',
        'as' => 'admin.peserta.pool.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/pool',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.ganda.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/peserta/ganda',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\GandaController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\GandaController@index',
        'as' => 'admin.peserta.ganda.index',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/ganda',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.ganda.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/peserta/ganda/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\GandaController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\GandaController@create',
        'as' => 'admin.peserta.ganda.create',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/ganda',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.ganda.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/peserta/ganda/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\GandaController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\GandaController@store',
        'as' => 'admin.peserta.ganda.store',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/ganda',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.ganda.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/peserta/ganda/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\GandaController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\GandaController@edit',
        'as' => 'admin.peserta.ganda.edit',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/ganda',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.ganda.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/peserta/ganda/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\GandaController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\GandaController@update',
        'as' => 'admin.peserta.ganda.update',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/ganda',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.ganda.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/peserta/ganda/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\GandaController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\GandaController@destroy',
        'as' => 'admin.peserta.ganda.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/ganda',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.tunggal.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/peserta/tunggal',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\TunggalController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\TunggalController@index',
        'as' => 'admin.peserta.tunggal.index',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/tunggal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.tunggal.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/peserta/tunggal/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\TunggalController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\TunggalController@create',
        'as' => 'admin.peserta.tunggal.create',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/tunggal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.tunggal.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/peserta/tunggal/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\TunggalController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\TunggalController@edit',
        'as' => 'admin.peserta.tunggal.edit',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/tunggal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.tunggal.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/peserta/tunggal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\TunggalController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\TunggalController@update',
        'as' => 'admin.peserta.tunggal.update',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/tunggal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.tunggal.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/peserta/tunggal/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\TunggalController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\TunggalController@store',
        'as' => 'admin.peserta.tunggal.store',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/tunggal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.tunggal.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/peserta/tunggal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\TunggalController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\TunggalController@destroy',
        'as' => 'admin.peserta.tunggal.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/tunggal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.regu.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/peserta/regu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\ReguController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\ReguController@index',
        'as' => 'admin.peserta.regu.index',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/regu',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.regu.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/peserta/regu/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\ReguController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\ReguController@create',
        'as' => 'admin.peserta.regu.create',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/regu',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.regu.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/peserta/regu/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\ReguController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\ReguController@store',
        'as' => 'admin.peserta.regu.store',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/regu',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.regu.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/peserta/regu/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\ReguController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\ReguController@edit',
        'as' => 'admin.peserta.regu.edit',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/regu',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.regu.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/peserta/regu/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\ReguController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\ReguController@update',
        'as' => 'admin.peserta.regu.update',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/regu',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.peserta.regu.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/peserta/regu/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\ReguController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\ReguController@destroy',
        'as' => 'admin.peserta.regu.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/peserta/regu',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.solo.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/manajemen/solo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@index',
        'as' => 'admin.manajemen.solo.index',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.solo.mulai' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/manajemen/solo/mulai/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@mulai',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@mulai',
        'as' => 'admin.manajemen.solo.mulai',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.solo.hukuman' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/solo/hukuman/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@updateHukuman',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@updateHukuman',
        'as' => 'admin.manajemen.solo.hukuman',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.solo.diskualifikasi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/solo/diskualifikasi/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@diskualifikasi',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@diskualifikasi',
        'as' => 'admin.manajemen.solo.diskualifikasi',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.solo.update-timer' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/solo/update-timer/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@updateTimer',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@updateTimer',
        'as' => 'admin.manajemen.solo.update-timer',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/manajemen/solo/get-status/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@getStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@getStatus',
        'as' => 'admin.manajemen.',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.generated::m6mFihxTqHJLcFCG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/manajemen/solo/get-juri-scores/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@getJuriScores',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@getJuriScores',
        'as' => 'admin.manajemen.generated::m6mFihxTqHJLcFCG',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.generated::OS5O4LNnFKjV0VZZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/solo/toggle-juri/{id_partai}/{no_juri}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@toggleStatusJuri',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@toggleStatusJuri',
        'as' => 'admin.manajemen.generated::OS5O4LNnFKjV0VZZ',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.generated::zir0oUX8mpFNTb5J' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/solo/toggle-status-input/{id_partai}/{no_juri}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@toggleStatusInput',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@toggleStatusInput',
        'as' => 'admin.manajemen.generated::zir0oUX8mpFNTb5J',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.ganda.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/manajemen/ganda',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@index',
        'as' => 'admin.manajemen.ganda.index',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.ganda.mulai' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/manajemen/ganda/mulai/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@mulai',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@mulai',
        'as' => 'admin.manajemen.ganda.mulai',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.ganda.hukuman' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/ganda/hukuman/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@updateHukuman',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@updateHukuman',
        'as' => 'admin.manajemen.ganda.hukuman',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.ganda.diskualifikasi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/ganda/diskualifikasi/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@diskualifikasi',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@diskualifikasi',
        'as' => 'admin.manajemen.ganda.diskualifikasi',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.ganda.update-timer' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/ganda/update-timer/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@updateTimer',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@updateTimer',
        'as' => 'admin.manajemen.ganda.update-timer',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.generated::haexRyRNb8ulU36b' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/manajemen/ganda/get-status/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@getStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@getStatus',
        'as' => 'admin.manajemen.generated::haexRyRNb8ulU36b',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.generated::4yBHvTfXlwC2N2k2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/manajemen/ganda/get-juri-scores/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@getJuriScores',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@getJuriScores',
        'as' => 'admin.manajemen.generated::4yBHvTfXlwC2N2k2',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.generated::utzrETRWeTPeGiYM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/ganda/toggle-juri/{id_partai}/{no_juri}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@toggleStatusJuri',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@toggleStatusJuri',
        'as' => 'admin.manajemen.generated::utzrETRWeTPeGiYM',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.generated::XgrVYQ7FrayrHWCo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/ganda/toggle-status-input/{id_partai}/{no_juri}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@toggleStatusInput',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@toggleStatusInput',
        'as' => 'admin.manajemen.generated::XgrVYQ7FrayrHWCo',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.tunggal.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/manajemen/tunggal',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@index',
        'as' => 'admin.manajemen.tunggal.index',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.tunggal.mulai' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/manajemen/tunggal/mulai/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@mulai',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@mulai',
        'as' => 'admin.manajemen.tunggal.mulai',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.tunggal.hukuman' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/tunggal/hukuman/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@updateHukuman',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@updateHukuman',
        'as' => 'admin.manajemen.tunggal.hukuman',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.tunggal.diskualifikasi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/tunggal/diskualifikasi/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@diskualifikasi',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@diskualifikasi',
        'as' => 'admin.manajemen.tunggal.diskualifikasi',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.tunggal.update-timer' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/tunggal/update-timer/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@updateTimer',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@updateTimer',
        'as' => 'admin.manajemen.tunggal.update-timer',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.generated::B2HbcRKZcGLvRlmb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/manajemen/tunggal/get-status/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@getStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@getStatus',
        'as' => 'admin.manajemen.generated::B2HbcRKZcGLvRlmb',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.generated::i3cfojz1ek2WrJ2I' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/manajemen/tunggal/get-juri-scores/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@getJuriScores',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@getJuriScores',
        'as' => 'admin.manajemen.generated::i3cfojz1ek2WrJ2I',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.generated::ENNzXWhx1PWKT9rG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/tunggal/toggle-juri/{id_partai}/{no_juri}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@toggleStatusJuriTunggal',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@toggleStatusJuriTunggal',
        'as' => 'admin.manajemen.generated::ENNzXWhx1PWKT9rG',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.generated::ZKSfNjzHySPWvdBl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/tunggal/toggle-status-input/{id_partai}/{no_juri}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@toggleStatusInput',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@toggleStatusInput',
        'as' => 'admin.manajemen.generated::ZKSfNjzHySPWvdBl',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.regu.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/manajemen/regu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@index',
        'as' => 'admin.manajemen.regu.index',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.regu.mulai' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/manajemen/regu/mulai/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@mulai',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@mulai',
        'as' => 'admin.manajemen.regu.mulai',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.regu.hukuman' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/regu/hukuman/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@updateHukuman',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@updateHukuman',
        'as' => 'admin.manajemen.regu.hukuman',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.regu.diskualifikasi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/regu/diskualifikasi/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@diskualifikasi',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@diskualifikasi',
        'as' => 'admin.manajemen.regu.diskualifikasi',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.regu.update-timer' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/regu/update-timer/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@updateTimer',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@updateTimer',
        'as' => 'admin.manajemen.regu.update-timer',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.generated::aiv7pVAswt1j3vxY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/manajemen/regu/get-status/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@getStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@getStatus',
        'as' => 'admin.manajemen.generated::aiv7pVAswt1j3vxY',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.generated::otHkUF56iEoYfN4Y' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/manajemen/regu/get-juri-scores/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@getJuriScores',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@getJuriScores',
        'as' => 'admin.manajemen.generated::otHkUF56iEoYfN4Y',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.generated::qUK2fFTqjGTicRig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/regu/toggle-juri/{id_partai}/{no_juri}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@toggleStatusJuriRegu',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@toggleStatusJuriRegu',
        'as' => 'admin.manajemen.generated::qUK2fFTqjGTicRig',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.generated::lCgB58lwRuUF7WpW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/regu/toggle-status-input/{id_partai}/{no_juri}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@toggleStatusInput',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@toggleStatusInput',
        'as' => 'admin.manajemen.generated::lCgB58lwRuUF7WpW',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.pool.mulai' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/pool/{id_partai}/mulai/{id_detail}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\PoolManajemenController@mulai',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\PoolManajemenController@mulai',
        'as' => 'admin.manajemen.pool.mulai',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.kelas.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/manajemen/kelas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'admin.manajemen.kelas.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\KelasController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\KelasController@index',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.kelas.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/manajemen/kelas/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'admin.manajemen.kelas.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\KelasController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\KelasController@create',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.kelas.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/manajemen/kelas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'admin.manajemen.kelas.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\KelasController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\KelasController@store',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.kelas.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/manajemen/kelas/{kela}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'admin.manajemen.kelas.show',
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\KelasController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\KelasController@show',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.kelas.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/manajemen/kelas/{kela}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'admin.manajemen.kelas.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\KelasController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\KelasController@edit',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.kelas.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/manajemen/kelas/{kela}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'admin.manajemen.kelas.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\KelasController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\KelasController@update',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.kelas.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/manajemen/kelas/{kela}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'admin.manajemen.kelas.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\KelasController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\KelasController@destroy',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.admin.manajemen.kelas.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/manajemen/kelas/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\KelasController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\KelasController@destroy',
        'as' => 'admin.manajemen.admin.manajemen.kelas.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.admin.manajemen.kelas.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/manajemen/kelas/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\KelasController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\KelasController@update',
        'as' => 'admin.manajemen.admin.manajemen.kelas.update',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.manajemen.pool.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/manajemen/pool',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\PoolManajemenController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\PoolManajemenController@index',
        'as' => 'admin.manajemen.pool.index',
        'namespace' => NULL,
        'prefix' => 'admin/manajemen',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.hasil.solo.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/hasil/solo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Hasil\\SoloController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Hasil\\SoloController@index',
        'as' => 'admin.hasil.solo.index',
        'namespace' => NULL,
        'prefix' => 'admin/hasil',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.hasil.solo.export-pdf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/hasil/solo/export-pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Hasil\\SoloController@exportPdf',
        'controller' => 'App\\Http\\Controllers\\Admin\\Hasil\\SoloController@exportPdf',
        'as' => 'admin.hasil.solo.export-pdf',
        'namespace' => NULL,
        'prefix' => 'admin/hasil',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.hasil.solo.tetapkan-pemenang' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/hasil/solo/{id}/tetapkan-pemenang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Hasil\\SoloController@tetapkanPemenang',
        'controller' => 'App\\Http\\Controllers\\Admin\\Hasil\\SoloController@tetapkanPemenang',
        'as' => 'admin.hasil.solo.tetapkan-pemenang',
        'namespace' => NULL,
        'prefix' => 'admin/hasil',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.hasil.solo.tutup-display' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/hasil/solo/{id}/tutup-display',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Hasil\\SoloController@tutupDisplay',
        'controller' => 'App\\Http\\Controllers\\Admin\\Hasil\\SoloController@tutupDisplay',
        'as' => 'admin.hasil.solo.tutup-display',
        'namespace' => NULL,
        'prefix' => 'admin/hasil',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.hasil.ganda.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/hasil/ganda',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Hasil\\GandaController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Hasil\\GandaController@index',
        'as' => 'admin.hasil.ganda.index',
        'namespace' => NULL,
        'prefix' => 'admin/hasil',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.hasil.ganda.export-pdf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/hasil/ganda/export-pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Hasil\\GandaController@exportPdf',
        'controller' => 'App\\Http\\Controllers\\Admin\\Hasil\\GandaController@exportPdf',
        'as' => 'admin.hasil.ganda.export-pdf',
        'namespace' => NULL,
        'prefix' => 'admin/hasil',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.hasil.ganda.tetapkan-pemenang' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/hasil/ganda/{id}/tetapkan-pemenang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Hasil\\GandaController@tetapkanPemenang',
        'controller' => 'App\\Http\\Controllers\\Admin\\Hasil\\GandaController@tetapkanPemenang',
        'as' => 'admin.hasil.ganda.tetapkan-pemenang',
        'namespace' => NULL,
        'prefix' => 'admin/hasil',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.hasil.ganda.tutup-display' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/hasil/ganda/{id}/tutup-display',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Hasil\\GandaController@tutupDisplay',
        'controller' => 'App\\Http\\Controllers\\Admin\\Hasil\\GandaController@tutupDisplay',
        'as' => 'admin.hasil.ganda.tutup-display',
        'namespace' => NULL,
        'prefix' => 'admin/hasil',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.hasil.tunggal.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/hasil/tunggal',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Hasil\\TunggalController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Hasil\\TunggalController@index',
        'as' => 'admin.hasil.tunggal.index',
        'namespace' => NULL,
        'prefix' => 'admin/hasil',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.hasil.tunggal.export-pdf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/hasil/tunggal/export-pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Hasil\\TunggalController@exportPdf',
        'controller' => 'App\\Http\\Controllers\\Admin\\Hasil\\TunggalController@exportPdf',
        'as' => 'admin.hasil.tunggal.export-pdf',
        'namespace' => NULL,
        'prefix' => 'admin/hasil',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.hasil.tunggal.tetapkan-pemenang' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/hasil/tunggal/{id}/tetapkan-pemenang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Hasil\\TunggalController@tetapkanPemenang',
        'controller' => 'App\\Http\\Controllers\\Admin\\Hasil\\TunggalController@tetapkanPemenang',
        'as' => 'admin.hasil.tunggal.tetapkan-pemenang',
        'namespace' => NULL,
        'prefix' => 'admin/hasil',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.hasil.tunggal.tutup-display' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/hasil/tunggal/{id}/tutup-display',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Hasil\\TunggalController@tutupDisplay',
        'controller' => 'App\\Http\\Controllers\\Admin\\Hasil\\TunggalController@tutupDisplay',
        'as' => 'admin.hasil.tunggal.tutup-display',
        'namespace' => NULL,
        'prefix' => 'admin/hasil',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.hasil.regu.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/hasil/regu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Hasil\\ReguController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Hasil\\ReguController@index',
        'as' => 'admin.hasil.regu.index',
        'namespace' => NULL,
        'prefix' => 'admin/hasil',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.hasil.regu.export-pdf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/hasil/regu/export-pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Hasil\\ReguController@exportPdf',
        'controller' => 'App\\Http\\Controllers\\Admin\\Hasil\\ReguController@exportPdf',
        'as' => 'admin.hasil.regu.export-pdf',
        'namespace' => NULL,
        'prefix' => 'admin/hasil',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.hasil.regu.tetapkan-pemenang' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/hasil/regu/{id}/tetapkan-pemenang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Hasil\\ReguController@tetapkanPemenang',
        'controller' => 'App\\Http\\Controllers\\Admin\\Hasil\\ReguController@tetapkanPemenang',
        'as' => 'admin.hasil.regu.tetapkan-pemenang',
        'namespace' => NULL,
        'prefix' => 'admin/hasil',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.hasil.regu.tutup-display' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/hasil/regu/{id}/tutup-display',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Hasil\\ReguController@tutupDisplay',
        'controller' => 'App\\Http\\Controllers\\Admin\\Hasil\\ReguController@tutupDisplay',
        'as' => 'admin.hasil.regu.tutup-display',
        'namespace' => NULL,
        'prefix' => 'admin/hasil',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.hasil.pool.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/hasil/pool',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Hasil\\HasilPoolController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Hasil\\HasilPoolController@index',
        'as' => 'admin.hasil.pool.index',
        'namespace' => NULL,
        'prefix' => 'admin/hasil',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.hasil.pool.tetapkan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/hasil/pool/{id}/tetapkan-pemenang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Hasil\\HasilPoolController@tetapkanPemenang',
        'controller' => 'App\\Http\\Controllers\\Admin\\Hasil\\HasilPoolController@tetapkanPemenang',
        'as' => 'admin.hasil.pool.tetapkan',
        'namespace' => NULL,
        'prefix' => 'admin/hasil',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.hasil.pool.tutup' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/hasil/pool/{id}/tutup-display',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Hasil\\HasilPoolController@tutupDisplay',
        'controller' => 'App\\Http\\Controllers\\Admin\\Hasil\\HasilPoolController@tutupDisplay',
        'as' => 'admin.hasil.pool.tutup',
        'namespace' => NULL,
        'prefix' => 'admin/hasil',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.hasil.pool.export-pdf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/hasil/pool/export-pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Hasil\\HasilPoolController@exportPdf',
        'controller' => 'App\\Http\\Controllers\\Admin\\Hasil\\HasilPoolController@exportPdf',
        'as' => 'admin.hasil.pool.export-pdf',
        'namespace' => NULL,
        'prefix' => 'admin/hasil',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nJYB02l72hdgy9v0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/cek-partai-aktif',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:193:"function () {
    $aktif = \\App\\Models\\DetailPesertaTanding::where(\'status_mulai\', 1)->first();
    return \\response()->json([
        \'id_detail\' => $aktif ? $aktif->id_detail : null
    ]);
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000005830000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::nJYB02l72hdgy9v0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'juri.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'juri/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:59:"function () {

    return \\view(\'pages.juri.dashboard\');

}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000005910000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'juri.dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.reset.semua' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/reset/semua',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ResetController@resetSemua',
        'controller' => 'App\\Http\\Controllers\\Admin\\ResetController@resetSemua',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'admin.reset.semua',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'juri.solo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'juri/solo/{no_juri}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:1311:"function ($no_juri) {

    // Cari partai yang detailnya SEDANG BERTANDING (status_mulai = 1)
    $partai = \\App\\Models\\Partai::with([\'kelas\', \'detail_peserta.peserta\'])
        ->whereHas(\'detail_peserta\', function ($q) {
            $q->where(\'status_mulai\', 1);
        })->first();

    $aktif = null;
    $nilai = null;
    $sudut = null;

    if ($partai) {
        $aktif = $partai->detail_peserta->where(\'status_mulai\', 1)->first();
        $sudut = \\strtolower($aktif->sudut);

        // Tarik nilai juri saat ini dari database
        $nilai = \\Illuminate\\Support\\Facades\\DB::table(\'input_nilai_juri\')
            ->where(\'id_detail\', $aktif->id_detail)
            ->where(\'no_juri\', $no_juri)
            ->first();
    }
    $kontrol = null;
    if ($partai) {
        $aktif = $partai->detail_peserta->where(\'status_mulai\', 1)->first();

        // Ambil data kontrol juri spesifik untuk juri ini
        $kontrol = \\Illuminate\\Support\\Facades\\DB::table(\'status_kontrol_juri\')
            ->where(\'id_partai\', $partai->id_partai)
            ->where(\'no_juri\', $no_juri)
            ->first();
    }

    // Jika tidak ada partai, kirim $partai = null (akan memicu Mode Standby di Blade)
    return \\view(\'pages.juri.solo\', \\compact(\'partai\', \'aktif\', \'sudut\', \'no_juri\', \'nilai\', \'kontrol\'));

}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000089d0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'juri.solo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'juri.ganda' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'juri/ganda/{no_juri}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:1312:"function ($no_juri) {

    // Cari partai yang detailnya SEDANG BERTANDING (status_mulai = 1)
    $partai = \\App\\Models\\Partai::with([\'kelas\', \'detail_peserta.peserta\'])
        ->whereHas(\'detail_peserta\', function ($q) {
            $q->where(\'status_mulai\', 1);
        })->first();

    $aktif = null;
    $nilai = null;
    $sudut = null;

    if ($partai) {
        $aktif = $partai->detail_peserta->where(\'status_mulai\', 1)->first();
        $sudut = \\strtolower($aktif->sudut);

        // Tarik nilai juri saat ini dari database
        $nilai = \\Illuminate\\Support\\Facades\\DB::table(\'input_nilai_juri\')
            ->where(\'id_detail\', $aktif->id_detail)
            ->where(\'no_juri\', $no_juri)
            ->first();
    }
    $kontrol = null;
    if ($partai) {
        $aktif = $partai->detail_peserta->where(\'status_mulai\', 1)->first();

        // Ambil data kontrol juri spesifik untuk juri ini
        $kontrol = \\Illuminate\\Support\\Facades\\DB::table(\'status_kontrol_juri\')
            ->where(\'id_partai\', $partai->id_partai)
            ->where(\'no_juri\', $no_juri)
            ->first();
    }

    // Jika tidak ada partai, kirim $partai = null (akan memicu Mode Standby di Blade)
    return \\view(\'pages.juri.ganda\', \\compact(\'partai\', \'aktif\', \'sudut\', \'no_juri\', \'nilai\', \'kontrol\'));

}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000089f0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'juri.ganda',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'juri.tunggal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'juri/tunggal/{no_juri}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:1543:"function ($no_juri) {

    // 1. Cari partai TUNGGAL yang detailnya SEDANG BERTANDING (status_mulai = 1)
    $partai = \\App\\Models\\Partai::with([\'kelas\', \'kategori\', \'detail_peserta.peserta\'])
        ->whereHas(\'kategori\', function ($q) {
            $q->where(\'nama_kategori\', \'LIKE\', \'%TUNGGAL%\');
        })
        ->whereHas(\'detail_peserta\', function ($q) {
            $q->where(\'status_mulai\', 1);
        })->first();

    $aktif = null;
    $inputJuri = null; // Menggunakan nama inputJuri agar sesuai dengan file blade tunggal
    $sudut = null;
    $kontrol = null;

    if ($partai) {
        // 2. Ambil detail peserta yang sedang tampil
        $aktif = $partai->detail_peserta->where(\'status_mulai\', 1)->first();
        $sudut = \\strtolower($aktif->sudut ?? \'\');

        // 3. Tarik nilai juri (Nilai A & Nilai B) dari database
        $inputJuri = \\Illuminate\\Support\\Facades\\DB::table(\'input_nilai_juri\')
            ->where(\'id_detail\', $aktif->id_detail)
            ->where(\'no_juri\', $no_juri)
            ->first();

        // 4. Ambil data kontrol juri (ON/OFF) spesifik untuk juri ini
        $kontrol = \\Illuminate\\Support\\Facades\\DB::table(\'status_kontrol_juri\')
            ->where(\'id_partai\', $partai->id_partai)
            ->where(\'no_juri\', $no_juri)
            ->first();
    }

    // Mengarah ke view tunggal yang baru saja didesain
    return \\view(\'pages.juri.tunggal\', \\compact(
        \'partai\',
        \'aktif\',
        \'sudut\',
        \'no_juri\',
        \'inputJuri\',
        \'kontrol\'
    ));

}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000008a10000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'juri.tunggal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'juri.regu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'juri/regu/{no_juri}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:1537:"function ($no_juri) {

    // 1. Cari partai TUNGGAL yang detailnya SEDANG BERTANDING (status_mulai = 1)
    $partai = \\App\\Models\\Partai::with([\'kelas\', \'kategori\', \'detail_peserta.peserta\'])
        ->whereHas(\'kategori\', function ($q) {
            $q->where(\'nama_kategori\', \'LIKE\', \'%REGU%\');
        })
        ->whereHas(\'detail_peserta\', function ($q) {
            $q->where(\'status_mulai\', 1);
        })->first();

    $aktif = null;
    $inputJuri = null; // Menggunakan nama inputJuri agar sesuai dengan file blade tunggal
    $sudut = null;
    $kontrol = null;

    if ($partai) {
        // 2. Ambil detail peserta yang sedang tampil
        $aktif = $partai->detail_peserta->where(\'status_mulai\', 1)->first();
        $sudut = \\strtolower($aktif->sudut ?? \'\');

        // 3. Tarik nilai juri (Nilai A & Nilai B) dari database
        $inputJuri = \\Illuminate\\Support\\Facades\\DB::table(\'input_nilai_juri\')
            ->where(\'id_detail\', $aktif->id_detail)
            ->where(\'no_juri\', $no_juri)
            ->first();

        // 4. Ambil data kontrol juri (ON/OFF) spesifik untuk juri ini
        $kontrol = \\Illuminate\\Support\\Facades\\DB::table(\'status_kontrol_juri\')
            ->where(\'id_partai\', $partai->id_partai)
            ->where(\'no_juri\', $no_juri)
            ->first();
    }

    // Mengarah ke view tunggal yang baru saja didesain
    return \\view(\'pages.juri.regu\', \\compact(
        \'partai\',
        \'aktif\',
        \'sudut\',
        \'no_juri\',
        \'inputJuri\',
        \'kontrol\'
    ));

}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000008a30000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'juri.regu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'juri.solo-ganda' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'juri/solo-ganda/{no_juri}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:1785:"function ($no_juri) {

    // 1. Cari partai SOLO atau GANDA yang detailnya SEDANG BERTANDING (status_mulai = 1)
    $partai = \\App\\Models\\Partai::with([\'kelas\', \'kategori\', \'detail_peserta.peserta\'])
        ->whereHas(\'kategori\', function ($q) {
            $q->where(\'nama_kategori\', \'LIKE\', \'%SOLO%\')
                ->orWhere(\'nama_kategori\', \'LIKE\', \'%GANDA%\');
        })
        ->whereHas(\'detail_peserta\', function ($q) {
            $q->where(\'status_mulai\', 1);
        })->first();

    $aktif = null;
    $nilai = null; // Variabel nilai untuk menampung skor dari database
    $sudut = null;
    $kontrol = null;

    if ($partai) {
        // 2. Ambil detail peserta yang sedang tampil (status_mulai = 1)
        $aktif = $partai->detail_peserta->where(\'status_mulai\', 1)->first();

        // Meskipun sistem pool/netral, variabel sudut tetap diambil untuk kebutuhan identifikasi di DB jika ada
        $sudut = \\strtolower($aktif->sudut ?? \'\');

        // 3. Tarik nilai juri (Nilai A, B, C) dari database berdasarkan id_detail peserta yang aktif
        $nilai = \\Illuminate\\Support\\Facades\\DB::table(\'input_nilai_juri\')
            ->where(\'id_detail\', $aktif->id_detail)
            ->where(\'no_juri\', $no_juri)
            ->first();

        // 4. Ambil data kontrol juri (ON/OFF & Status Input) spesifik untuk juri ini
        $kontrol = \\Illuminate\\Support\\Facades\\DB::table(\'status_kontrol_juri\')
            ->where(\'id_partai\', $partai->id_partai)
            ->where(\'no_juri\', $no_juri)
            ->first();
    }

    // Mengarah ke view solo_ganda (Netral/Tanpa Warna Sudut Dominan)
    return \\view(\'pages.juri.solo_ganda\', \\compact(
        \'partai\',
        \'aktif\',
        \'sudut\',
        \'no_juri\',
        \'nilai\',
        \'kontrol\'
    ));

}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000008a50000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'juri.solo-ganda',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'juri.solo.simpan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'juri/solo/simpan/{id_detail}/{no_juri}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@simpanNilaiJuri',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\SoloController@simpanNilaiJuri',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'juri.solo.simpan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'juri.ganda.simpan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'juri/ganda/simpan/{id_detail}/{no_juri}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@simpanNilaiJuri',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\MatchGandaController@simpanNilaiJuri',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'juri.ganda.simpan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'juri.solo-ganda.simpan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'juri/solo-ganda/simpan/{id_detail}/{no_juri}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@simpanNilaiPool',
        'controller' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@simpanNilaiPool',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'juri.solo-ganda.simpan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'juri.tunggal.input-nilai' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'juri/tunggal/input-nilai/{id_partai}/{no_juri}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@inputNilaiJuri',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@inputNilaiJuri',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'juri.tunggal.input-nilai',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'juri.regu.input-nilai' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'juri/regu/input-nilai/{id_partai}/{no_juri}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@inputNilaiJuri',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@inputNilaiJuri',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'juri.regu.input-nilai',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'juri.tunggal.simpan-nilai-final' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'juri/tunggal/simpan-nilai/{id_detail}/{no_juri}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@simpanNilaiJuri',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\TunggalController@simpanNilaiJuri',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'juri.tunggal.simpan-nilai-final',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'juri.tunggal.selesai' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'juri/tunggal/selesai/{id_partai}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Peserta\\TunggalController@selesai',
        'controller' => 'App\\Http\\Controllers\\Admin\\Peserta\\TunggalController@selesai',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'juri.tunggal.selesai',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'juri.regu.simpan-nilai-final' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'juri/regu/simpan-nilai/{id_detail}/{no_juri}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@simpanNilaiJuri',
        'controller' => 'App\\Http\\Controllers\\Admin\\Manajemen\\ReguController@simpanNilaiJuri',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'juri.regu.simpan-nilai-final',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dewan.solo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dewan/solo/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:1965:"function ($id, $sudut) {
    // Mengambil data partai untuk ditampilkan di kontrol dewan
    $partai = \\App\\Models\\Partai::with([\'kelas\', \'detail_peserta.peserta\'])->findOrFail($id);
    // --- TAMBAHAN LOGIKA AUTO-GENERATE JURI ---
    $sudutDb = \\ucfirst($sudut);
    $aktif = $partai->detail_peserta->where(\'sudut\', $sudutDb)->first();

    if ($aktif) {
        // Cek apakah data juri untuk id_detail ini sudah ada?
        $jumlahJuri = \\Illuminate\\Support\\Facades\\DB::table(\'input_nilai_juri\')
            ->where(\'id_detail\', $aktif->id_detail)
            ->count();

        // Jika belum ada 6 juri, buatkan defaultnya
        if ($jumlahJuri < 6) {
            $dataJuri = [];
            for ($i = 1; $i <= 6; $i++) {
                $dataJuri[] = [
                    \'id_detail\' => $aktif->id_detail,
                    \'no_juri\' => $i,
                    \'nilai_a\' => 0.00,
                    \'nilai_b\' => 0.00,
                    \'nilai_c\' => 0.00,
                    \'skor_akhir_juri\' => 9.10, // Nilai default solo
                ];
            }
            \\Illuminate\\Support\\Facades\\DB::table(\'input_nilai_juri\')->insert($dataJuri);
        }

        // --- LOGIKA 2: Auto-Generate Kontrol Juri ---
        $jumlahKontrol = \\Illuminate\\Support\\Facades\\DB::table(\'status_kontrol_juri\')->where(\'id_partai\', $id)->count();
        if ($jumlahKontrol < 6) {
            $dataKontrol = [];
            for ($i = 1; $i <= 6; $i++) {
                $dataKontrol[] = [
                    \'id_partai\' => $id, // Menggunakan id_partai sesuai skema Anda
                    \'no_juri\' => $i,
                    \'is_on\' => 0, // 0 = OFF (Merah) defaultnya
                    \'status_input\' => \'Proses\', // Default Proses (Oranye)
                ];
            }
            \\Illuminate\\Support\\Facades\\DB::table(\'status_kontrol_juri\')->insert($dataKontrol);
        }
    }
    return \\view(\'pages.dewan.solo\', \\compact(\'partai\', \'sudut\'));
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000008af0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'dewan.solo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dewan.ganda' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dewan/ganda/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:2047:"function ($id, $sudut) {
    // 1. Ambil data partai dan peserta (Eager Loading)
    $partai = \\App\\Models\\Partai::with([\'kelas\', \'detail_peserta.peserta\'])->findOrFail($id);

    $sudutDb = \\ucfirst($sudut);
    // Untuk Ganda, kita ambil id_detail pertama dari pasangan tersebut sebagai anchor nilai
    $aktif = $partai->detail_peserta->where(\'sudut\', $sudutDb)->first();

    if ($aktif) {
        // --- LOGIKA 1: Auto-Generate Input Nilai Juri (6 Juri) ---
        $jumlahJuri = \\Illuminate\\Support\\Facades\\DB::table(\'input_nilai_juri\')
            ->where(\'id_detail\', $aktif->id_detail)
            ->count();

        if ($jumlahJuri < 6) {
            $dataJuri = [];
            for ($i = 1; $i <= 6; $i++) {
                $dataJuri[] = [
                    \'id_detail\' => $aktif->id_detail,
                    \'no_juri\' => $i,
                    \'nilai_a\' => 0.00,
                    \'nilai_b\' => 0.00,
                    \'nilai_c\' => 0.00,
                    \'skor_akhir_juri\' => 9.10, // Default Ganda (sama dengan Solo)
                ];
            }
            \\Illuminate\\Support\\Facades\\DB::table(\'input_nilai_juri\')->insert($dataJuri);
        }

        // --- LOGIKA 2: Auto-Generate Kontrol Juri (6 Juri) ---
        // Kontrol juri biasanya per ID Partai agar Dewan bisa melihat status ke-6 juri secara global
        $jumlahKontrol = \\Illuminate\\Support\\Facades\\DB::table(\'status_kontrol_juri\')
            ->where(\'id_partai\', $id)
            ->count();

        if ($jumlahKontrol < 6) {
            $dataKontrol = [];
            for ($i = 1; $i <= 6; $i++) {
                $dataKontrol[] = [
                    \'id_partai\' => $id,
                    \'no_juri\' => $i,
                    \'is_on\' => 0,
                    \'status_input\' => \'Proses\',
                ];
            }
            \\Illuminate\\Support\\Facades\\DB::table(\'status_kontrol_juri\')->insert($dataKontrol);
        }
    }

    // Mengarahkan ke view dewan ganda
    return \\view(\'pages.dewan.ganda\', \\compact(\'partai\', \'sudut\'));
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000008b10000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'dewan.ganda',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dewan.tunggal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dewan/tunggal/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:1929:"function ($id, $sudut) {
    // Mengambil data partai untuk ditampilkan di kontrol dewan
    $partai = \\App\\Models\\Partai::with([\'kelas\', \'detail_peserta.peserta\'])->findOrFail($id);
    // --- TAMBAHAN LOGIKA AUTO-GENERATE JURI ---
    $sudutDb = \\ucfirst($sudut);
    $aktif = $partai->detail_peserta->where(\'sudut\', $sudutDb)->first();

    if ($aktif) {
        // Cek apakah data juri untuk id_detail ini sudah ada?
        $jumlahJuri = \\Illuminate\\Support\\Facades\\DB::table(\'input_nilai_juri\')
            ->where(\'id_detail\', $aktif->id_detail)
            ->count();

        // Jika belum ada 6 juri, buatkan defaultnya
        if ($jumlahJuri < 6) {
            $dataJuri = [];
            for ($i = 1; $i <= 6; $i++) {
                $dataJuri[] = [
                    \'id_detail\' => $aktif->id_detail,
                    \'no_juri\' => $i,
                    \'nilai_a\' => 0.00,
                    \'nilai_b\' => 0.00,
                    \'skor_akhir_juri\' => 9.90, // Nilai default solo
                ];
            }
            \\Illuminate\\Support\\Facades\\DB::table(\'input_nilai_juri\')->insert($dataJuri);
        }

        // --- LOGIKA 2: Auto-Generate Kontrol Juri ---
        $jumlahKontrol = \\Illuminate\\Support\\Facades\\DB::table(\'status_kontrol_juri\')->where(\'id_partai\', $id)->count();
        if ($jumlahKontrol < 6) {
            $dataKontrol = [];
            for ($i = 1; $i <= 6; $i++) {
                $dataKontrol[] = [
                    \'id_partai\' => $id, // Menggunakan id_partai sesuai skema Anda
                    \'no_juri\' => $i,
                    \'is_on\' => 0, // 0 = OFF (Merah) defaultnya
                    \'status_input\' => \'Proses\', // Default Proses (Oranye)
                ];
            }
            \\Illuminate\\Support\\Facades\\DB::table(\'status_kontrol_juri\')->insert($dataKontrol);
        }
    }
    return \\view(\'pages.dewan.tunggal\', \\compact(\'partai\', \'sudut\'));
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000008b30000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'dewan.tunggal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dewan.regu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dewan/regu/{id}/{sudut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:1926:"function ($id, $sudut) {
    // Mengambil data partai untuk ditampilkan di kontrol dewan
    $partai = \\App\\Models\\Partai::with([\'kelas\', \'detail_peserta.peserta\'])->findOrFail($id);
    // --- TAMBAHAN LOGIKA AUTO-GENERATE JURI ---
    $sudutDb = \\ucfirst($sudut);
    $aktif = $partai->detail_peserta->where(\'sudut\', $sudutDb)->first();

    if ($aktif) {
        // Cek apakah data juri untuk id_detail ini sudah ada?
        $jumlahJuri = \\Illuminate\\Support\\Facades\\DB::table(\'input_nilai_juri\')
            ->where(\'id_detail\', $aktif->id_detail)
            ->count();

        // Jika belum ada 6 juri, buatkan defaultnya
        if ($jumlahJuri < 6) {
            $dataJuri = [];
            for ($i = 1; $i <= 6; $i++) {
                $dataJuri[] = [
                    \'id_detail\' => $aktif->id_detail,
                    \'no_juri\' => $i,
                    \'nilai_a\' => 0.00,
                    \'nilai_b\' => 0.00,
                    \'skor_akhir_juri\' => 9.90, // Nilai default solo
                ];
            }
            \\Illuminate\\Support\\Facades\\DB::table(\'input_nilai_juri\')->insert($dataJuri);
        }

        // --- LOGIKA 2: Auto-Generate Kontrol Juri ---
        $jumlahKontrol = \\Illuminate\\Support\\Facades\\DB::table(\'status_kontrol_juri\')->where(\'id_partai\', $id)->count();
        if ($jumlahKontrol < 6) {
            $dataKontrol = [];
            for ($i = 1; $i <= 6; $i++) {
                $dataKontrol[] = [
                    \'id_partai\' => $id, // Menggunakan id_partai sesuai skema Anda
                    \'no_juri\' => $i,
                    \'is_on\' => 0, // 0 = OFF (Merah) defaultnya
                    \'status_input\' => \'Proses\', // Default Proses (Oranye)
                ];
            }
            \\Illuminate\\Support\\Facades\\DB::table(\'status_kontrol_juri\')->insert($dataKontrol);
        }
    }
    return \\view(\'pages.dewan.regu\', \\compact(\'partai\', \'sudut\'));
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000008b50000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'dewan.regu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dewan.pool.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dewan/pool/{id_partai}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@index',
        'as' => 'dewan.pool.index',
        'namespace' => NULL,
        'prefix' => '/dewan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dewan.pool.diskualifikasi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dewan/pool/{id}/diskualifikasi/{id_detail}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@diskualifikasi',
        'controller' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@diskualifikasi',
        'as' => 'dewan.pool.diskualifikasi',
        'namespace' => NULL,
        'prefix' => '/dewan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dewan.pool.selesai' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dewan/pool/{id}/selesai/{id_detail}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@selesai',
        'controller' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@selesai',
        'as' => 'dewan.pool.selesai',
        'namespace' => NULL,
        'prefix' => '/dewan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dewan.pool.update-hukuman' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dewan/pool/update-hukuman',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@updateHukuman',
        'controller' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@updateHukuman',
        'as' => 'dewan.pool.update-hukuman',
        'namespace' => NULL,
        'prefix' => '/dewan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dewan.pool.update-timer' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dewan/pool/update-timer/{id}/{id_detail}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@updateTimer',
        'controller' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@updateTimer',
        'as' => 'dewan.pool.update-timer',
        'namespace' => NULL,
        'prefix' => '/dewan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dewan.pool.hukuman' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dewan/pool/hukuman/{id}/{id_detail}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@updateHukuman',
        'controller' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@updateHukuman',
        'as' => 'dewan.pool.hukuman',
        'namespace' => NULL,
        'prefix' => '/dewan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dewan.pool.toggle-juri' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dewan/pool/toggle-juri/{id_partai}/{no_juri}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@toggleJuri',
        'controller' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@toggleJuri',
        'as' => 'dewan.pool.toggle-juri',
        'namespace' => NULL,
        'prefix' => '/dewan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dewan.pool.toggle-status-input' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dewan/pool/toggle-status-input/{id_partai}/{no_juri}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@toggleStatusInput',
        'controller' => 'App\\Http\\Controllers\\Admin\\Dewan\\PoolController@toggleStatusInput',
        'as' => 'dewan.pool.toggle-status-input',
        'namespace' => NULL,
        'prefix' => '/dewan',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mkA7Gva2fToIb2Qb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'broadcasting/auth',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Illuminate\\Broadcasting\\BroadcastController@authenticate',
        'controller' => '\\Illuminate\\Broadcasting\\BroadcastController@authenticate',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'excluded_middleware' => 
        array (
          0 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
        ),
        'as' => 'generated::mkA7Gva2fToIb2Qb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
